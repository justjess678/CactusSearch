import vueGraphique.Frame;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*BoundaryBienvenue bb = new BoundaryBienvenue(new ControlConnexion());
		BoundaryChoixRecherche bcr = new BoundaryChoixRecherche();
		
		int type = bb.messageBienvenue();
		bcr.afficherRecherche(type);*/
		/*BoundaryCreerProfil bcp = new BoundaryCreerProfil();
		Admin Admin;
		Admin admin;*/
		//BDAdmin bdAdmin = BDAdmin.getInstance();
		/*BDAdmin bdAdmin = BDAdmin.getInstance();
		ControlModifierProfil cmp = new ControlModifierProfil();
		BoundaryVisualiserHistorique bvh= new BoundaryVisualiserHistorique();
		ControlEnregistrerHistorique ceh = new ControlEnregistrerHistorique();
		ControlEnregistrerBD ceBD = new ControlEnregistrerBD();
		ControlChargerBD ccBD = new ControlChargerBD();*/
		
		//bcp.creerProfilAdmin("logan", "marvel", "Dhellemmes", "Louis");
		//bcp.creerProfilAdmin("Wolverine", "DC", "Mallent", "Nicolas");
		
		/*Scanner sc = new Scanner(System.in);
		System.out.println("nouveau Admin 1");
		System.out.println("Entrez le login");
		String login = sc.nextLine();
		System.out.println("Entrez le mdp");
		String mdp = sc.nextLine();
		System.out.println("Entrez le nom");
		String nom = sc.nextLine();
		System.out.println("Entrez le prenom");
		String prenom = sc.nextLine();
		bcp.creerProfilAdmin(login, mdp, nom, prenom);
		
		System.out.println("nouveau Admin 2");
		System.out.println("Entrez le login");
		String login1 = sc.nextLine();
		System.out.println("Entrez le mdp");
		String mdp1 = sc.nextLine();
		System.out.println("Entrez le nom");
		String nom1 = sc.nextLine();
		System.out.println("Entrez le prenom");
		String prenom1 = sc.nextLine();
		bcp.creerProfilAdmin(login1, mdp1, nom1, prenom1);*/
		
		//Admin = bdAdmin.getAdmin(1);
		
		//System.out.println(bdAdmin.toString());
		//bdAdmin.connexionAdmin(login, mdp);
		//ceBD.controlEnregistrerBD();
		//ccBD.controlChargerBD();
		/*System.out.println("nouveau Admin 3");
		System.out.println("Entrez le login");
		String login2 = sc.nextLine();
		System.out.println("Entrez le mdp");
		String mdp2 = sc.nextLine();
		System.out.println("Entrez le nom");
		String nom2 = sc.nextLine();
		System.out.println("Entrez le prenom");
		String prenom2 = sc.nextLine();
		bcp.creerProfilAdmin(login2, mdp2, nom2, prenom2);
		
		System.out.println("nouveau Admin 4");
		System.out.println("Entrez le login");
		String login3 = sc.nextLine();
		System.out.println("Entrez le mdp");
		String mdp3 = sc.nextLine();
		System.out.println("Entrez le nom");
		String nom3 = sc.nextLine();
		System.out.println("Entrez le prenom");
		String prenom3 = sc.nextLine();
		bcp.creerProfilAdmin(login3, mdp3, nom3, prenom3);
		
		ceBD.controlEnregistrerBD();
		
		bdAdmin.supprimerAdmin(1);
		bdAdmin.supprimerAdmin(2);
		bdAdmin.supprimerAdmin(3);
		bdAdmin.supprimerAdmin(4);
		
		ccBD.controlChargerBD();
		System.out.println(bdAdmin.toString());*/
		
		
		
		//ceh.controlEnregistrerHistorique(1);
		
		//bvh.boundaryVisualiserHistorique(1);
		
		Frame myframe =new Frame();
		myframe.setVisible(true);
		
	}

}
