package vueGraphique;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

import vue.BoundaryVisualiserBD;
import vue.BoundaryVisualiserHistorique;

public class panelBDUtil extends JPanel {

	BoundaryVisualiserBD bvb = new BoundaryVisualiserBD();
	String[] cheminsImages = new String[300];
	JScrollPane utilScroll;

	public panelBDUtil() {
		initComponents();
	}

	public JList initialisationScroll() {

		// dans listoffiles chaque case = 1 ligne de resultat.txt

		ArrayList<String> listOfUtil = new ArrayList<String>();

		// inserer les infos des UTIL
		for (int i = 0; i < bvb.boundaryVisualiserBDUtil().size(); i++) {
			listOfUtil.add(bvb.boundaryVisualiserBDUtil().get(i));
		}

		JList list = null;
		DefaultListModel listModel;
		listModel = new DefaultListModel();
		int count = 0;
		int j = 0;
		listModel.addElement("UTILISATEURS");
		listModel.addElement("            ID | mot de passe | nom | prenom | ");
		for (int i = 0; i < listOfUtil.size(); i++) {
		//on remplit la liste avec les valeurs du fichier
			String name = listOfUtil.get(i).toString();
			list = new JList(listModel);
			listModel.addElement(listOfUtil.get(i).toString());
			list.setFixedCellHeight(60);
			list.setFixedCellWidth(50);
			list.setBorder(new EmptyBorder(10, 20, 20, 20));
			list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		}
		return list;

	}

	private void initComponents() {
		//geree par NetBeans
		rechPanel = new javax.swing.JPanel();

		boutonAccueil = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();

		setBackground(new java.awt.Color(239, 227, 175));
		setMinimumSize(new java.awt.Dimension(720, 480));
		setPreferredSize(new java.awt.Dimension(720, 480));
		setLayout(null);

		rechPanel.setBackground(new java.awt.Color(175, 226, 26));
		rechPanel.setMinimumSize(new java.awt.Dimension(720, 10));
		rechPanel.setName("SearchPanel"); // NOI18N
		rechPanel.setPreferredSize(new java.awt.Dimension(720, 50));
		rechPanel.setLayout(null);

		boutonAccueil.setText("Accueil");
		boutonAccueil.setBounds(270, 10, 190, 40);
		rechPanel.add(boutonAccueil);

		add(rechPanel);
		rechPanel.setBounds(0, 0, 720, 60);
		utilScroll = new javax.swing.JScrollPane(initialisationScroll());
		utilScroll.setBackground(new java.awt.Color(255, 255, 255));
		utilScroll.setMinimumSize(new java.awt.Dimension(720, 400));
		add(utilScroll);
		utilScroll.setBounds(40, 100, 640, 320);

		jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
		jLabel1.setText("Base de Données Utilisateurs");
		add(jLabel1);
		jLabel1.setBounds(40, 60, 500, 40);
	}

	public javax.swing.JButton boutonAccueil;
	javax.swing.JLabel jLabel1;
	javax.swing.JPanel rechPanel;
}
