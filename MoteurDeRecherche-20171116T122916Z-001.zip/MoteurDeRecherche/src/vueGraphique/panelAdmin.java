package vueGraphique;

import model.Stockage;
import vue.BoundaryConnexion;
import vue.BoundaryCreerProfil;
import control.ControlEnregistrerBD;


public class panelAdmin extends javax.swing.JPanel {public panelAdmin() {
		initComponents();
	}
	
	Stockage Stock = Stockage.getInstance();
	
	private void initComponents() {

		carrevertinscrit = new javax.swing.JPanel();
        carrebeigeinscrit = new javax.swing.JPanel();
        prenom = new javax.swing.JTextField();
        imgprofil2 = new javax.swing.JLabel();
        mdpAdmin = new javax.swing.JTextField();
        mdp = new javax.swing.JTextField();
        nom = new javax.swing.JTextField();
        validinscri = new javax.swing.JButton();
        id = new javax.swing.JTextField();

        setLayout(null);

        carrevertinscrit.setBackground(new java.awt.Color(175, 226, 26));
        carrevertinscrit.setLayout(null);
        add(carrevertinscrit);
        carrevertinscrit.setBounds(0, 0, 720, 61);

        carrebeigeinscrit.setBackground(new java.awt.Color(239, 227, 175));
        carrebeigeinscrit.setLayout(null);
        
        validinscri.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				validinscriActionPerformed(evt);
			}
		});
        
        prenom.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        prenom.setText("prenom");
        prenom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prenomActionPerformed(evt);
            }
        });
        carrebeigeinscrit.add(prenom);
        prenom.setBounds(80, 280, 150, 40);

        imgprofil2.setIcon(new javax.swing.ImageIcon("imageprofil.png")); // NOI18N
		carrebeigeinscrit.add(imgprofil2);
		imgprofil2.setBounds(280, 90, 150, 160);

        mdpAdmin.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        mdpAdmin.setText("Mdp Admin");
        mdpAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	mdpAdminActionPerformed(evt);
            }
        });
        carrebeigeinscrit.add(mdpAdmin);
        mdpAdmin.setBounds(410, 350, 180, 40);

        mdp.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        mdp.setText("motdepasse");
        mdp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mdpActionPerformed(evt);
            }
        });
        carrebeigeinscrit.add(mdp);
        mdp.setBounds(160, 350, 150, 40);

        nom.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        nom.setText("nom");
        nom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomActionPerformed(evt);
            }
        });
        carrebeigeinscrit.add(nom);
        nom.setBounds(290, 280, 150, 40);

        validinscri.setText("Valider");
        carrebeigeinscrit.add(validinscri);
        validinscri.setBounds(280, 410, 140, 40);

        id.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        id.setText("identifiant");
        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });
        carrebeigeinscrit.add(id);
        id.setBounds(490, 280, 150, 40);

        add(carrebeigeinscrit);
        carrebeigeinscrit.setBounds(0, 0, 720, 461);
    }// </editor-fold>                        
//champ de texte pour le nom action en g�n�ral (clique , touche clavier etcc) 
	// attendre un clique sur le boutton valider inscription et faire un gettext sur tous les champs; m�me code que pour la bar de recherche sauf que l'event sera
	
	private void validinscriActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		String firstname ,lastname,password,ident,supermdp;
		BoundaryCreerProfil bcp = new BoundaryCreerProfil();
		ControlEnregistrerBD ceBD = new ControlEnregistrerBD();
		BoundaryConnexion bc = new BoundaryConnexion();
		
		ident = id.getText();
		password = mdp.getText();
		firstname = prenom.getText();
		lastname = nom.getText();
		supermdp = mdpAdmin.getText();
		
		bcp.creerProfilAdmin(ident, password, lastname,firstname, supermdp);
		//ceBD.controlEnregistrerBD();
		Stock.setNumeroUtil(bc.connexion(ident, password));
		Stock.setLogin(ident);
		Stock.setMdp(password);

		id.setText("identifiant");
		nom.setText("nom");
		prenom.setText("prenom");
		mdp.setText("motdepasse");
		mdpAdmin.setText("mdpAdmin");
		ceBD.controlEnregistrerBD();
		
	}
	
	// un mouse event sur validinscri
	private void nomActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}
	private void mdpAdminActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}
	//champ de texte pour le prenom action en g�n�ral (clique , touche clavier etcc) pareil que pour le nom
	private void prenomActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	//champ de texte pour l'ID action en g�n�ral (clique , touche clavier etcc) pareil que pour le nom
	private void idActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	//champ de texte pour le MDP action en g�n�ral (clique , touche clavier etcc) pareil que pour le nom
	private void mdpActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	// Variables declaration - do not modify
	javax.swing.JPanel carrebeigeinscrit;
	javax.swing.JPanel carrevertinscrit;
	javax.swing.JTextField id;
	javax.swing.JLabel imgprofil2;
	javax.swing.JTextField mdp;
	javax.swing.JTextField nom;
	javax.swing.JTextField prenom;
	javax.swing.JButton validinscri;
	javax.swing.JTextField mdpAdmin;
	// End of variables declaration
}
