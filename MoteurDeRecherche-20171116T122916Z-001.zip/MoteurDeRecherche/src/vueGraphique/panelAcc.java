package vueGraphique;

import java.awt.event.KeyEvent;
import java.io.IOException;

import model.BDAdmin;
import model.BDUtilisateur;
import model.Stockage;
import vue.BoundaryRecherche;
import vue.BoundaryRechercheCouleur;
import vue.BoundaryRechercheMotClefs;
import control.ControlDeconnexion;
import control.ControlEnregistrerHistorique;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author Clement
 */
public class panelAcc extends javax.swing.JPanel {
	public int type;

	Stockage Stock = Stockage.getInstance();
	private BoundaryRechercheCouleur brc = new BoundaryRechercheCouleur();
	private BoundaryRecherche br = new BoundaryRecherche();
	private BoundaryRechercheMotClefs brmc = new BoundaryRechercheMotClefs();
	private ControlEnregistrerHistorique ceh = new ControlEnregistrerHistorique();

	BDUtilisateur bdu = BDUtilisateur.getInstance();
	BDAdmin bda = BDAdmin.getInstance();

	// int numeroProfil = 0;
	static String couleur1 = "rouge";
	static String couleur2 = "vert";
	static String couleur3 = "bleu";
	static String couleur4 = "jaune";
	static String recherche = null;

	public panelAcc() {
		initComponents();
	}

	private void initComponents() {
		// d�claration composants
		barsearch = new javax.swing.JTextField();
		motclef = new javax.swing.JRadioButton();
		motclef.setSelected(true);
		imgrgb = new javax.swing.JRadioButton();
		imgnb = new javax.swing.JRadioButton();
		file = new javax.swing.JRadioButton();
		carrevert = new javax.swing.JPanel();
		connexion = new javax.swing.JButton();
		inscrire = new javax.swing.JButton();
		deco = new javax.swing.JButton();
		logo = new javax.swing.JLabel();
		nomdeco = new javax.swing.JLabel();
		option = new javax.swing.JButton();
		// ici et jusqu'a ////////////FIN/////////// ne pas toucher car c'est
		// ici que tous les composants sont plac�s,
		// coloris� et sur lesquelles on ajout un listener donc sauf pour
		// modifier le rendue visuelle ne PAS TOUCHER merci ^^ :P
		setBackground(new java.awt.Color(239, 227, 175));
		setLayout(null);

		barsearch.setText("Tapez votre recherche");
		barsearch.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				barsearchActionPerformed(evt);
			}
		});
		barsearch.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyPressed(java.awt.event.KeyEvent evt) {
				barsearchKeyPressed(evt);
			}
		});
		add(barsearch);
		barsearch.setBounds(210, 400, 263, 42);

		logo.setIcon(new javax.swing.ImageIcon("cactuslogo.png")); // NOI18N
		add(logo);
		logo.setBounds(60, 70, 604, 270);

		motclef.setText("Mot Clef");
		motclef.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				motclefActionPerformed(evt);
			}
		});
		add(motclef);
		motclef.setActionCommand("motclef");
		motclef.setBounds(50, 350, 90, 30);

		imgrgb.setText("ImageRGB");
		add(imgrgb);
		imgrgb.setActionCommand("imgrgb");
		imgrgb.setBounds(290, 350, 110, 30);

		imgnb.setText("ImageNB");
		add(imgnb);
		imgnb.setActionCommand("imgnb");
		imgnb.setBounds(430, 350, 100, 30);

		file.setText("Fichier");
		add(file);
		file.setActionCommand("file");
		file.setBounds(170, 350, 90, 30);

		domin = new javax.swing.JRadioButton();
		domin.setText("Couleur");
		add(domin);
		domin.setActionCommand("domin");
		domin.setBounds(560, 350, 100, 30);

		// groupe de button
		group = new javax.swing.ButtonGroup();
		group.add(imgnb);
		group.add(imgrgb);
		group.add(file);
		group.add(motclef);
		group.add(domin);
		carrevert.setBackground(new java.awt.Color(175, 226, 26));
		carrevert.setLayout(null);

		carrevert.setBackground(new java.awt.Color(175, 226, 26));
		carrevert.setLayout(null);

		connexion.setText("Connexion");
		connexion.setPreferredSize(new java.awt.Dimension(75, 23));
		connexion.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				connexionActionPerformed(evt);
			}
		});
		carrevert.add(connexion);
		connexion.setBounds(420, 20, 130, 30);

		nomdeco = new javax.swing.JLabel();
		carrevert.add(nomdeco);
		nomdeco.setBounds(440, 20, 110, 30);
		nomdeco.setVisible(false);

		// inscrire.setBackground(new java.awt.Color(144, 120, 160));
		inscrire.setText("S'inscrire");
		inscrire.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				inscrireActionPerformed(evt);
			}
		});
		carrevert.add(inscrire);
		inscrire.setBounds(570, 20, 110, 30);

		deco.setText("Deconnexion");
		deco.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				decoActionPerformed(evt);
			}
		});
		deco.setBounds(560, 10, 130, 40);
		option.setText("Options");
		option.setBounds(30, 20, 100, 30);

		add(carrevert);
		carrevert.setBounds(0, 0, 720, 61);
	}// </editor-fold>
		// //////////////////////////FIN///////////////////////////////

	// ceci sont tous les listeners du panelAcc qui permet d'associer une action
	// � un composant du panel ,
	// example pour la bar de recherche j'ai associer l'event appuyer sur la
	// touche entree ( VK_ENTER) a recuperer le texte contenue dans la bar de
	// recher

	// bar de recherche action en g�n�ral (clique , touche clavier etcc)
	private void barsearchActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	public int getType() {
		return type;
	}

	// bar de recherche action avec les touche du clavier (ici ne r�agit qu'a la
	// touche entr�e
	private void barsearchKeyPressed(java.awt.event.KeyEvent evt) {
		// TODO add your handling code here:
		int key = evt.getKeyCode();
		if (key == KeyEvent.VK_ENTER) {

			recherche = barsearch.getText();
			String selec = group.getSelection().getActionCommand();
			switch (selec) {
			case "motclef":
				// methode de controlleur recherche mot cle
				// System.out.println("rech. par mot cle");
				brmc.rechercheMotClefs(recherche);

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				this.type = 1;

				if (!bdu.listeUtilisateursIsEmpty()) {
					for (int clef : bdu.getlisteUtilisateurs().keySet()) {
						if (bdu.getlisteUtilisateurs()
								.get(clef)
								.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bdu.getUtilisateur(Stock.getNumeroUtil())
									.isConnecte()) {
								ceh.controlEnregistrerHistoriqueUtilisateur(Stock
										.getNumeroUtil());
							}
						}
					}
				}

				if (!bda.listeAdminIsEmpty()) {
					for (int clef : bda.getlisteAdmins().keySet()) {
						if (bda.getlisteAdmins()
								.get(clef)
								.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bda.getAdmin(Stock.getNumeroUtil())
									.isConnecte()) {
								ceh.controlEnregistrerHistoriqueAdmin(Stock
										.getNumeroUtil());
							}
						}
					}
				}

				break;
			case "file":
				// methode de controlleur comparer descripteur txt
				// System.out.println("rech par desc txt");
				this.br.rechercheTI(recherche);

				try {
					Thread.sleep(400);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				this.type = 1;

				if (!bdu.listeUtilisateursIsEmpty()) {
					for (int clef : bdu.getlisteUtilisateurs().keySet()) {
						if (bdu.getlisteUtilisateurs()
								.get(clef)
								.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bdu.getUtilisateur(Stock.getNumeroUtil())
									.isConnecte()) {
								ceh.controlEnregistrerHistoriqueUtilisateur(Stock
										.getNumeroUtil());
							}
						}
					}
				}

				if (!bda.listeAdminIsEmpty()) {
					for (int clef : bda.getlisteAdmins().keySet()) {
						if (bda.getlisteAdmins()
								.get(clef)
								.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bda.getAdmin(Stock.getNumeroUtil())
									.isConnecte()) {
								ceh.controlEnregistrerHistoriqueAdmin(Stock
										.getNumeroUtil());
							}
						}
					}
				}

				break;
			case "imgrgb":
				// methode de controlleur comparer descripteur img RGB
				// System.out.println("rech par decs img RGB");
				this.br.rechercheTI(recherche);

				try {
					Thread.sleep(300);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				this.type = 2;

				if (!bdu.listeUtilisateursIsEmpty()) {
					for (int clef : bdu.getlisteUtilisateurs().keySet()) {
						if (bdu.getlisteUtilisateurs()
								.get(clef)
								.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bdu.getUtilisateur(Stock.getNumeroUtil())
									.isConnecte()) {
								ceh.controlEnregistrerHistoriqueUtilisateur(Stock
										.getNumeroUtil());
							}
						}
					}
				}

				if (!bda.listeAdminIsEmpty()) {
					for (int clef : bda.getlisteAdmins().keySet()) {
						if (bda.getlisteAdmins()
								.get(clef)
								.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bda.getAdmin(Stock.getNumeroUtil())
									.isConnecte()) {
								ceh.controlEnregistrerHistoriqueAdmin(Stock
										.getNumeroUtil());
							}
						}
					}
				}

				// resuRGB.removeAll(resuRGB);
				break;
			case "imgnb":
				// methode de controlleur comparer descripteur img NB
				// System.out.println("rech par desc img NB");
				this.br.rechercheTI(recherche);

				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				this.type = 3;

				if (!bdu.listeUtilisateursIsEmpty()) {
					for (int clef : bdu.getlisteUtilisateurs().keySet()) {
						if (bdu.getlisteUtilisateurs()
								.get(clef)
								.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bdu.getUtilisateur(Stock.getNumeroUtil())
									.isConnecte()) {
								ceh.controlEnregistrerHistoriqueUtilisateur(Stock
										.getNumeroUtil());
							}
						}
					}
				}

				if (!bda.listeAdminIsEmpty()) {
					for (int clef : bda.getlisteAdmins().keySet()) {
						if (bda.getlisteAdmins()
								.get(clef)
								.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bda.getAdmin(Stock.getNumeroUtil())
									.isConnecte()) {
								ceh.controlEnregistrerHistoriqueAdmin(Stock
										.getNumeroUtil());
							}
						}
					}
				}

				// resuNB.removeAll(resuNB);
				break;
			case "domin":
				// recherche couleur dom
				// System.out.println("rech par couleur dominante");

				try {
					brc.rechCouleur(recherche);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				this.type = 2;

				if (!bdu.listeUtilisateursIsEmpty()) {
					for (int clef : bdu.getlisteUtilisateurs().keySet()) {
						if (bdu.getlisteUtilisateurs()
								.get(clef)
								.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bdu.getUtilisateur(Stock.getNumeroUtil())
									.isConnecte()) {
								ceh.controlEnregistrerHistoriqueUtilisateur(Stock
										.getNumeroUtil());
							}
						}
					}
				}

				if (!bda.listeAdminIsEmpty()) {
					for (int clef : bda.getlisteAdmins().keySet()) {
						if (bda.getlisteAdmins()
								.get(clef)
								.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bda.getAdmin(Stock.getNumeroUtil())
									.isConnecte()) {
								ceh.controlEnregistrerHistoriqueAdmin(Stock
										.getNumeroUtil());
							}
						}
					}
				}

				break;
			// ////////////// IMPORTANT ICI LANCER LA RECHERCHE
			// ///////////////////////////
			// System.out.println(recherche); decommenter pour tester
			}
		}
		
	}

	// sur le choix du mode action en g�n�ral (clique , touche clavier etcc)
	// id�e faire un getfocus pour voir lequels et slectionner
	private void motclefActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void decoActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		
		ControlDeconnexion cd = new ControlDeconnexion();
		cd.controlDeconnexion(Stock.getLogin(), Stock.getMdp());

		Stock.setNumeroUtil(-1);
		Stock.setLogin("");
		Stock.setMdp("");

	}

	// boutton de connexion action en g�n�ral (clique , touche clavier etcc)
	// rien a faire ici
	private void connexionActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	// boutton inscription action en g�n�ral (clique , touche clavier etcc) rien
	// a faire ici
	private void inscrireActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	// Variables declaration - do not modify
	javax.swing.JTextField barsearch;
	javax.swing.JPanel carrevert;
	javax.swing.JButton connexion;
	javax.swing.JRadioButton file;
	javax.swing.JRadioButton imgnb;
	javax.swing.JRadioButton imgrgb;
	javax.swing.JButton inscrire;
	javax.swing.JRadioButton motclef;
	javax.swing.JRadioButton domin;
	javax.swing.JLabel logo;
	javax.swing.ButtonGroup group;
	javax.swing.JButton deco;
	javax.swing.JLabel nomdeco;
	javax.swing.JButton option;
	// End of variables declaration
}
