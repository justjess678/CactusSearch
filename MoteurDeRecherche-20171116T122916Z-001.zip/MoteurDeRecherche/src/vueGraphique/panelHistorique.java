package vueGraphique;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

import vue.BoundaryVisualiserHistorique;

public class panelHistorique extends JPanel {

	BoundaryVisualiserHistorique bvh = new BoundaryVisualiserHistorique();
	String[] cheminsImages=new String[300];
	JScrollPane histScroll;
	
	public panelHistorique(){
		initComponents();
	}

	public JList initialisationScroll() {

		// dans listoffiles chaque case = 1 ligne de resultat.txt = un résultat

		ArrayList<String> listOfFiles = new ArrayList<String>();
		String chemin = "";

		for (int i = 0; i < bvh.boundaryVisualiserHistorique().size(); i++) {
			listOfFiles.add(chemin + bvh.boundaryVisualiserHistorique().get(i));
		}

		// File[] listOfFiles = folder.listFiles();
		JList list = null;
		DefaultListModel listModel;
		listModel = new DefaultListModel();
		int count = 0;
		int j = 0;
		for (int i = 0; i < listOfFiles.size(); i++) {
			//on ajoute chaque resultat au JList qui sera ans le JScrollPane
			String name = listOfFiles.get(i).toString();
			list = new JList(listModel);
			if (name.endsWith("xml")) {
				//on ajoute les fichiers texte au JList
				listModel
						.addElement(listOfFiles
								.get(i)
								.toString()
								.substring(
										listOfFiles.get(i).toString()
												.lastIndexOf("/") + 1));
				//on le rend plus joli
				list.setFixedCellHeight(60);
				list.setFixedCellWidth(50);
				list.setBorder(new EmptyBorder(10, 20, 20, 20));
			}
			if (name.endsWith("jpg") || name.endsWith("png")) {
				//on ajoute les images RGB
				chemin = "/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basedeDonneefichier/IMG_RGB/";
				//Pour les afficher il faut passer par un ImageIcon
				ImageIcon imageIcon = null;
				try {
					imageIcon = new ImageIcon(ImageIO.read(new File(chemin
							+ listOfFiles.get(i))));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} // load the image to a
					// imageIcon
				Image image = imageIcon.getImage(); // transform it
				Image newimg = image.getScaledInstance(120, 120,
						java.awt.Image.SCALE_SMOOTH);
				//On change sa taille pour que ce soit plus uniforme
				imageIcon = new ImageIcon(newimg);
				cheminsImages[j] = chemin + listOfFiles.get(i).toString();
				j++;
				listModel.addElement(imageIcon);
				list.setBorder(new EmptyBorder(10, 20, 20, 20));
			}
			if (name.endsWith("bmp")) {
				//images noir + blanc
				chemin = "/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basedeDonneefichier/IMG_NG/";
				//Idem il faut passer par un ImageIcon pour l'afficher
				ImageIcon imageIcon = null;
				try {
					imageIcon = new ImageIcon(ImageIO.read(new File(chemin
							+ listOfFiles.get(i))));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} // load the image to a
					// imageIcon
				Image image = imageIcon.getImage(); // transform it
				Image newimg = image.getScaledInstance(120, 120,
						java.awt.Image.SCALE_SMOOTH); // scale
														// it
														// the
														// smooth
														// way
				imageIcon = new ImageIcon(newimg);
				cheminsImages[j] = chemin + listOfFiles.get(i).toString();
				j++;

				listModel.addElement(imageIcon);
				list.setBorder(new EmptyBorder(10, 20, 20, 20));
			}
			list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		}
		return list;

	}

	private void initComponents() {
		//geree par Netbeans
		rechPanel = new javax.swing.JPanel();
		
		boutonAccueil=new javax.swing.JButton();
		boutonOuvrir = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();

		setBackground(new java.awt.Color(239, 227, 175));
		setMinimumSize(new java.awt.Dimension(720, 480));
		setPreferredSize(new java.awt.Dimension(720, 480));
		setLayout(null);

		rechPanel.setBackground(new java.awt.Color(175, 226, 26));
		rechPanel.setMinimumSize(new java.awt.Dimension(720, 10));
		rechPanel.setName("SearchPanel"); // NOI18N
		rechPanel.setPreferredSize(new java.awt.Dimension(720, 50));
		rechPanel.setLayout(null);


		boutonAccueil.setText("Accueil");
		boutonAccueil.setBounds(270, 10, 190, 40);
		rechPanel.add(boutonAccueil);

		add(rechPanel);
		rechPanel.setBounds(0, 0, 720, 60);
		histScroll = new javax.swing.JScrollPane(initialisationScroll());
		histScroll.setBackground(new java.awt.Color(255, 255, 255));
		histScroll.setMinimumSize(new java.awt.Dimension(720, 400));
		add(histScroll);
		histScroll.setBounds(40, 100, 640, 320);

		jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
		jLabel1.setText("Historique");
		add(jLabel1);
		jLabel1.setBounds(40, 60, 370, 40);
	}
	
	javax.swing.JButton boutonOuvrir;
	public javax.swing.JButton boutonAccueil;
	javax.swing.JLabel jLabel1;
	javax.swing.JPanel rechPanel;
}
