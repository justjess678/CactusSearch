package vueGraphique;

import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

import vue.BoundaryAfficherResultat;

public class panelResultat extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JList listAff = new JList();
	private String[] cheminsImages = new String[100];
	private int type = 0;
	private BoundaryAfficherResultat bar = new BoundaryAfficherResultat();

	public panelResultat(int type) {
		// TODO Auto-generated constructor stub
		// type de recherche 1=text, 2=imagergb, 3image nb
		this.type = type;
		this.initComponents(type);
	}

	private void boutonOuvrirActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_boutonOuvrirActionPerformed
		// On ouvre le fichier sélectionné
		switch (this.type) {
		case 1:// text
			String chemin = "/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basedeDonneefichier/Textes/";

			try {
				Runtime.getRuntime().exec(
						"gedit " + chemin + this.listAff.getSelectedValue());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 2:// image RGB
			int i = this.listAff.getSelectedIndex();

			try {
				Runtime.getRuntime().exec("gthumb " + this.cheminsImages[i]);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 3:// image nb
			i = this.listAff.getSelectedIndex();
			
			try {
				Runtime.getRuntime().exec("gthumb " + this.cheminsImages[i]);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		default:
			System.out
					.println("ERREUR lors de l'ouverture du fichier: type invalide");
			break;
		}
	}// GEN-LAST:event_boutonOuvrirActionPerformed

	// 1= text, 2=img
	public JList initialisationScroll() {
		// TODO vrai cheimin
		// dans listoffiles chaque case = 1 ligne de resultat.txt
		ArrayList<String> listOfFiles = new ArrayList<String>();
		String chemin = "";
		//chemin different selon le type de fichier
		switch (type) {
		case 1:// texte
			chemin = "/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basedeDonneefichier/Textes/";
			break;
		case 2:// images rgb
			chemin = "/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basedeDonneefichier/IMG_RGB/";
			break;
		case 3: //image nb
			chemin = "/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basedeDonneefichier/IMG_NG/";
			break;
		default:

			break;
		}
		//on met tous les resultats dans listOfFiles
		for (int i = 0; i < bar.envoieDataBoundary().size(); i++) {
			listOfFiles.add(chemin + bar.envoieDataBoundary().get(i));
		}

		// File[] listOfFiles = folder.listFiles();
		JList list = null;
		DefaultListModel listModel;
		listModel = new DefaultListModel();
		int count = 0;
		int j = 0;
		//on met chaque element dans le JList qui sera mis dan le JScrollPane
		for (int i = 0; i < listOfFiles.size(); i++) {
			String name = listOfFiles.get(i).toString();
			list = new JList(listModel);
			switch (type) {
			case 1:// text
				if (name.endsWith("xml")) {
					listModel.addElement(listOfFiles
							.get(i)
							.toString()
							.substring(
									listOfFiles.get(i).toString()
											.lastIndexOf("/") + 1));
					list.setFixedCellHeight(60);
					list.setFixedCellWidth(50);
					list.setBorder(new EmptyBorder(10, 20, 20, 20));
				}
				break;
			case 2: // image
				if (name.endsWith("jpg")) {
					ImageIcon imageIcon = null;
					try {
						imageIcon = new ImageIcon(ImageIO.read(new File(
								listOfFiles.get(i))));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} // load the image to a
						// imageIcon
					Image image = imageIcon.getImage(); // transform it
					Image newimg = image.getScaledInstance(120, 120,
							java.awt.Image.SCALE_SMOOTH); // scale
															// it
															// the
															// smooth
															// way
					imageIcon = new ImageIcon(newimg);
					cheminsImages[j] = listOfFiles.get(i).toString();
					j++;
					listModel.addElement(imageIcon);
					list.setBorder(new EmptyBorder(10, 20, 20, 20));
				}
				break;
			case 3: // image nb
				if (name.endsWith("bmp")) {
					ImageIcon imageIcon = null;
					try {
						imageIcon = new ImageIcon(ImageIO.read(new File(
								listOfFiles.get(i))));
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} // load the image to a
						// imageIcon
					Image image = imageIcon.getImage(); // transform it
					Image newimg = image.getScaledInstance(120, 120,
							java.awt.Image.SCALE_SMOOTH); // scale
															// it
															// the
															// smooth
															// way
					imageIcon = new ImageIcon(newimg);
					cheminsImages[j] = listOfFiles.get(i).toString();
					j++;
					System.out.println(i);
					listModel.addElement(imageIcon);
					list.setBorder(new EmptyBorder(10, 20, 20, 20));
				}
				break;
			default:
				break;
			}
			list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		}
		listAff = list;
		return list;

	}

	private void initComponents(int type) {
		//geree par NetBeans
		rechPanel = new javax.swing.JPanel();
		//seule difference: on initialise le scroll pane avec notre liste
		rechScroll = new javax.swing.JScrollPane(initialisationScroll());
		boutonAccueil=new javax.swing.JButton();
		boutonOuvrir = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();

		setBackground(new java.awt.Color(239, 227, 175));
		setMinimumSize(new java.awt.Dimension(720, 480));
		setPreferredSize(new java.awt.Dimension(720, 480));
		setLayout(null);

		rechPanel.setBackground(new java.awt.Color(175, 226, 26));
		rechPanel.setMinimumSize(new java.awt.Dimension(720, 10));
		rechPanel.setName("SearchPanel"); // NOI18N
		rechPanel.setPreferredSize(new java.awt.Dimension(720, 50));
		rechPanel.setLayout(null);


		boutonAccueil.setText("Accueil");
		boutonAccueil.setBounds(270, 10, 190, 40);
		rechPanel.add(boutonAccueil);

		add(rechPanel);
		rechPanel.setBounds(0, 0, 720, 60);

		rechScroll.setBackground(new java.awt.Color(255, 255, 255));
		rechScroll.setMinimumSize(new java.awt.Dimension(720, 400));
		add(rechScroll);
		rechScroll.setBounds(40, 100, 640, 320);

		boutonOuvrir.setText("Ouvrir");
		boutonOuvrir.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				boutonOuvrirActionPerformed(evt);
			}
		});
		add(boutonOuvrir);
		boutonOuvrir.setBounds(553, 430, 110, 30);

		jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
		jLabel1.setText("Résultats de la recherche");
		add(jLabel1);
		jLabel1.setBounds(40, 60, 370, 40);
	}// </editor-fold>//GEN-END:initComponents
		// m�me code que pour barsearch


	// Variables declaration - do not modify//GEN-BEGIN:variables
	javax.swing.JButton boutonOuvrir;
	javax.swing.JButton boutonAccueil;
	javax.swing.JLabel jLabel1;
	javax.swing.JPanel rechPanel;
	javax.swing.JScrollPane rechScroll;
	// End of variables declaration//GEN-END:variables
}
