package vueGraphique;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JFrame;

import model.BDAdmin;
import model.BDUtilisateur;
import model.Stockage;

public class Frame extends JFrame implements ActionListener {

	Stockage Stock = Stockage.getInstance();
	BDUtilisateur bdu = BDUtilisateur.getInstance();
	BDAdmin bda = BDAdmin.getInstance();

	private static final long serialVersionUID = 1L;
	// Panel
	panelAcc panAcc = new panelAcc();
	panelResultat panRes = new panelResultat(2);
	panelInscrit panIns = new panelInscrit();
	panelAdmin panAdmin = new panelAdmin();
	panelConnexion panCo = new panelConnexion();
	panelCharg panCharg = new panelCharg();
	panelHistorique panHisto = new panelHistorique();
	panelModifierProfil panModifProfil = new panelModifierProfil();
	panelOption panOpt = new panelOption();
	panelDesc panDesc = new panelDesc();
	panelBDAdmin panelBDAdmin = new panelBDAdmin();
	panelBDUtil panelBDUtil = new panelBDUtil();
	boolean connecter = false;

	public Frame() {
		add(panCharg);

		// TODO Auto-generated method stub
		this.setTitle("Cactus Search");
		this.setSize(720, 480);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		// init tous les panels sauf celui de base a false voir pour rajouter un
		// panel d'attente avec un gif
		panRes.setVisible(false);
		panIns.setVisible(false);
		panCo.setVisible(false);
		panAdmin.setVisible(false);
		panAcc.setVisible(false);
		panHisto.setVisible(false);
		panModifProfil.setVisible(false);
		panOpt.setVisible(false);

		// add un listener sur tous les composants donc on se sert pour voir les
		// actions effectuer dessus
		panCo.boutonConnexion.addActionListener(this);
		panAcc.barsearch.addActionListener(this);
		panAcc.connexion.addActionListener(this);
		panAcc.inscrire.addActionListener(this);
		panIns.validinscri.addActionListener(this);
		panIns.admin.addActionListener(this);
		panAdmin.validinscri.addActionListener(this);
		panAcc.deco.addActionListener(this);
		panCharg.charge.addActionListener(this);
		panAcc.option.addActionListener(this);
		panModifProfil.validmodif.addActionListener(this);
		panOpt.retourAcc.addActionListener(this);
		panOpt.modifProfil.addActionListener(this);
		panAcc.option.addActionListener(this);
		panOpt.voirHisto.addActionListener(this);
		panOpt.voirAdmin.addActionListener(this);
		panOpt.voirUser.addActionListener(this);
		panOpt.voirDesc.addActionListener(this);
		panHisto.boutonAccueil.addActionListener(this);
		panDesc.descNB.addActionListener(this);
		panDesc.descRGB.addActionListener(this);
		panDesc.descText.addActionListener(this);
		panDesc.accueil.addActionListener(this);
		panelBDAdmin.boutonAccueil.addActionListener(this);
		panelBDUtil.boutonAccueil.addActionListener(this);
		panOpt.Suppr.addActionListener(this);
		// FINAL
		// affiche la frame
		this.setVisible(true);
	}

	// ici on g�re les changements de frame a chaque clique sur un boutton ou
	// autre
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource().equals(panAcc.barsearch)) {
			panAcc.setVisible(false);
			// System.out.println("action");
			// CLEMENT : CES 3 LIGNES QUI SUIVENT SONT SUPER MEGA IMPORTANTS
			// POUR LA RECHERCHE
			this.panRes = new panelResultat(this.panAcc.getType());
			panRes.boutonAccueil.addActionListener(this);
			add(panRes);
			panRes.setVisible(true);
			panAcc.barsearch.setText("Tapez votre recherche");
			// ajouter dans historique si connecter
		} else if (e.getSource().equals(panCo.boutonConnexion)) {

			for (int key : bdu.getlisteUtilisateurs().keySet()) {

				if (bdu.getlisteUtilisateurs()
						.get(key)
						.selecteProfil(panCo.textFieldLogin.getText(),
								panCo.jPasswordField1.getText())) {

					panCo.setVisible(false);
					add(panAcc);
					panAcc.carrevert.remove(panAcc.connexion);
					panAcc.carrevert.remove(panAcc.inscrire);
					panAcc.carrevert.add(panAcc.deco);
					panAcc.carrevert.add(panAcc.nomdeco);
					panAcc.carrevert.add(panAcc.option);
					panAcc.nomdeco.setVisible(true);
					panAcc.nomdeco.setText(panCo.textFieldLogin.getText());
					panAcc.setVisible(true);
				} else {
					panCo.setVisible(false);
					add(panAcc);
					panAcc.setVisible(true);
				}
			}
			for (int key1 : bda.getlisteAdmins().keySet()) {

				if (bda.getlisteAdmins()
						.get(key1)
						.selecteProfil(panCo.textFieldLogin.getText(),
								panCo.jPasswordField1.getText())) {

					panCo.setVisible(false);
					add(panAcc);
					panAcc.carrevert.remove(panAcc.connexion);
					panAcc.carrevert.remove(panAcc.inscrire);
					panAcc.carrevert.add(panAcc.deco);
					panAcc.carrevert.add(panAcc.nomdeco);
					panAcc.carrevert.add(panAcc.option);
					panAcc.nomdeco.setVisible(true);
					panAcc.nomdeco.setText(panCo.textFieldLogin.getText());
					panAcc.setVisible(true);
				} else {
					panCo.setVisible(false);
					add(panAcc);
					panAcc.setVisible(true);
				}
			}

		} else if (e.getSource().equals(panIns.validinscri)) {
			panIns.setVisible(false);
			add(panAcc);
			panAcc.carrevert.remove(panAcc.connexion);
			panAcc.carrevert.remove(panAcc.inscrire);
			panAcc.carrevert.add(panAcc.deco);
			panAcc.carrevert.add(panAcc.nomdeco);
			panAcc.nomdeco.setVisible(true);
			panAcc.nomdeco.setText(panIns.id.getText());
			panAcc.setVisible(true);
			// ajouter a la bdclient
		} else if (e.getSource().equals(panIns.admin)) {
			panIns.setVisible(false);
			add(panAdmin);
			panAdmin.setVisible(true);
		} else if (e.getSource().equals(panAcc.connexion)) {
			panAcc.setVisible(false);
			add(panCo);
			panCo.setVisible(true);

		} else if (e.getSource().equals(panAcc.inscrire)) {
			panAcc.setVisible(false);
			add(panIns);
			panAcc.carrevert.remove(panAcc.connexion);
			panAcc.carrevert.remove(panAcc.inscrire);
			panAcc.carrevert.add(panAcc.nomdeco);
			panAcc.carrevert.add(panAcc.deco);
			panAcc.carrevert.add(panAcc.option);
			panIns.setVisible(true);
		} else if (e.getSource().equals(panAdmin.validinscri)) {
			panAdmin.setVisible(false);
			add(panAcc);
			if(panAdmin.mdpAdmin.getText().equals("porygon")){
				panAcc.carrevert.remove(panAcc.connexion);
				panAcc.carrevert.remove(panAcc.inscrire);
				panAcc.carrevert.add(panAcc.nomdeco);
				panAcc.nomdeco.setVisible(true);
				panAcc.nomdeco.setText(panAdmin.id.getText());
				panAcc.carrevert.add(panAcc.deco);
				panAcc.carrevert.add(panAcc.option);
				panOpt.add(panOpt.voirAdmin);
				panOpt.add(panOpt.voirUser);
				panOpt.add(panOpt.lanceIndex);
				panOpt.add(panOpt.voirDesc);
			}else {
				panAcc.nomdeco.setVisible(false);
				panAcc.carrevert.remove(panAcc.deco);
				panAcc.carrevert.remove(panAcc.option);
				panAcc.carrevert.add(panAcc.connexion);
				panAcc.carrevert.add(panAcc.inscrire);
				panAcc.carrevert.remove(panAcc.nomdeco);
			}
			panAcc.setVisible(true);
		} else if (e.getSource().equals(panAcc.deco)) {
			panAcc.setVisible(false);
			add(panAcc);
			panAcc.carrevert.add(panAcc.connexion);
			panAcc.carrevert.add(panAcc.inscrire);
			panAcc.carrevert.remove(panAcc.nomdeco);
			panAcc.carrevert.remove(panAcc.option);
			panAcc.carrevert.remove(panAcc.deco);
			panAcc.setVisible(true);
		} else if (e.getSource().equals(panCharg.charge)) {
			panCharg.setVisible(false);
			add(panAcc);
			panAcc.setVisible(true);
			remove(panCharg);
		} else if (e.getSource().equals(panAcc.option)) {
			panAcc.setVisible(false);
			for (int key1 : bda.getlisteAdmins().keySet()) {
				if (bda.getlisteAdmins().get(key1)
						.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
					add(panOpt);
					panOpt.add(panOpt.voirAdmin);
					panOpt.add(panOpt.voirUser);
					panOpt.add(panOpt.lanceIndex);
					panOpt.add(panOpt.voirDesc);
					panOpt.setVisible(true);
				}
			}
			for (int key : bdu.getlisteUtilisateurs().keySet()) {
				if (bdu.getlisteUtilisateurs().get(key)
						.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
					panOpt.remove(panOpt.voirAdmin);
					panOpt.remove(panOpt.voirUser);
					panOpt.remove(panOpt.lanceIndex);
					panOpt.remove(panOpt.voirDesc);
					add(panOpt);
					panOpt.setVisible(true);
				}
			}

		} else if (e.getSource().equals(panModifProfil.validmodif)) {
			panModifProfil.setVisible(false);
			add(panAcc);
			panAcc.nomdeco.setText(panModifProfil.id.getText());
			panAcc.setVisible(true);
		} else if (e.getSource().equals(panOpt.modifProfil)) {
			panOpt.setVisible(false);
			add(panModifProfil);
			panModifProfil.setVisible(true);
		} else if (e.getSource().equals(panOpt.retourAcc)) {
			panOpt.setVisible(false);
			add(panAcc);
			panAcc.setVisible(true);
		} else if (e.getSource().equals(panHisto.boutonAccueil)) {
			panHisto.setVisible(false);
			add(panAcc);
			panAcc.setVisible(true);
		} else if (e.getSource().equals(panOpt.voirHisto)) {
			panOpt.setVisible(false);
			panHisto = new panelHistorique();
			panHisto.boutonAccueil.addActionListener(this);
			add(panHisto);
			panHisto.setVisible(true);
		} else if (e.getSource().equals(panRes.boutonAccueil)) {
			panRes.setVisible(false);
			add(panAcc);
			panAcc.setVisible(true);
		} else if (e.getSource().equals(panDesc.accueil)) {
			panDesc.setVisible(false);
			add(panAcc);
			panAcc.setVisible(true);
		} else if (e.getSource().equals(panelBDAdmin.boutonAccueil)) {
			panelBDAdmin.setVisible(false);
			add(panAcc);
			panAcc.setVisible(true);
		} else if (e.getSource().equals(panelBDUtil.boutonAccueil)) {
			panelBDUtil.setVisible(false);
			add(panAcc);
			panAcc.setVisible(true);
		} else if (e.getSource().equals(panOpt.voirDesc)) {
			panOpt.setVisible(false);
			add(panDesc);
			panDesc.setVisible(true);
		} else if (e.getSource().equals(panDesc.accueil)) {
			panDesc.setVisible(false);
			add(panAcc);
			panAcc.setVisible(true);
		} else if (e.getSource().equals(panDesc.descText)) {
			// lancer gedit + txt
			String chemin = "/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basededonneedescripteurs/BdDescripteur.txt";
			try {
				Runtime.getRuntime().exec("gedit " + chemin);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else if (e.getSource().equals(panDesc.descNB)) {
			// lancer gedit + descNB
			String chemin = "/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basededonneedescripteurs/BdDescripteurImage.txt";
			try {
				Runtime.getRuntime().exec("gedit " + chemin);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else if (e.getSource().equals(panDesc.descRGB)) {
			// lancer gedit + descNB
			String chemin = "/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basededonneedescripteurs/BdDescripteurImageRGB.txt";
			try {
				Runtime.getRuntime().exec("gedit " + chemin);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else if (e.getSource().equals(panOpt.voirAdmin)) {
			panOpt.setVisible(false);
			panelBDAdmin = new panelBDAdmin();
			panelBDAdmin.boutonAccueil.addActionListener(this);
			add(panelBDAdmin);
			panelBDAdmin.setVisible(true);
		} else if (e.getSource().equals(panOpt.voirUser)) {
			panOpt.setVisible(false);
			panelBDUtil = new panelBDUtil();
			panelBDUtil.boutonAccueil.addActionListener(this);
			add(panelBDUtil);
			panelBDUtil.setVisible(true);
		} else if (e.getSource().equals(panOpt.Suppr)) {
			panOpt.setVisible(false);
			add(panOpt);
			panAcc.carrevert.add(panAcc.connexion);
			panAcc.carrevert.add(panAcc.inscrire);
			panAcc.carrevert.remove(panAcc.option);
			panAcc.carrevert.remove(panAcc.deco);
			panAcc.carrevert.remove(panAcc.nomdeco);
			panAcc.setVisible(true);
		}
	}
}
