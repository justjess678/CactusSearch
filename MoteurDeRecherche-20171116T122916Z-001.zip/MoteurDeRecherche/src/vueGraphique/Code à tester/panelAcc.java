package vueGraphique;

import java.awt.event.KeyEvent;
import java.io.IOException;

import model.BDAdmin;
import model.BDUtilisateur;
import model.Stockage;
import vue.BoundaryRecherche;
import vue.BoundaryRechercheCouleur;
import vue.BoundaryRechercheMotClefs;
import control.ControlDeconnexion;
import control.ControlEnregistrerHistorique;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author Clement
 */
public class panelAcc extends javax.swing.JPanel {
	public int type;

	Stockage Stock = Stockage.getInstance();
	private BoundaryRechercheCouleur brc = new BoundaryRechercheCouleur();
	private BoundaryRecherche br = new BoundaryRecherche();
	private BoundaryRechercheMotClefs brmc = new BoundaryRechercheMotClefs();
	private ControlEnregistrerHistorique ceh = new ControlEnregistrerHistorique();

	BDUtilisateur bdu = BDUtilisateur.getInstance();
	BDAdmin bda = BDAdmin.getInstance();

	// int numeroProfil = 0;
	static String couleur1 = "rouge";
	static String couleur2 = "vert";
	static String couleur3 = "bleu";
	static String couleur4 = "jaune";
	static String recherche = null;

	public panelAcc() {
		initComponents();
	}

	private void initComponents() {

		// init types des composants
		barsearch = new javax.swing.JTextField();
		motclef = new javax.swing.JRadioButton();
		motclef.setSelected(true);
		imgrgb = new javax.swing.JRadioButton();
		imgnb = new javax.swing.JRadioButton();
		file = new javax.swing.JRadioButton();
		carrevert = new javax.swing.JPanel();
		connexion = new javax.swing.JButton();
		inscrire = new javax.swing.JButton();
		deco = new javax.swing.JButton();
		logo = new javax.swing.JLabel();
		nomdeco = new javax.swing.JLabel();
		option = new javax.swing.JButton();

		// init couleur du bakcground
		setBackground(new java.awt.Color(239, 227, 175));
		// init layout = null pour placer les composants comme bon nou semble
		setLayout(null);

		// ajout de texte dans la bar de recherche
		barsearch.setText("Tapez votre recherche");
		// ajout listener sur cette barre
		barsearch.addKeyListener(new java.awt.event.KeyAdapter() {
			public void keyPressed(java.awt.event.KeyEvent evt) {
				barsearchKeyPressed(evt);
			}
		});
		// ajout de la barre dans le panel
		add(barsearch);
		// positionnement
		barsearch.setBounds(210, 400, 263, 42);

		// charge logo du projet
		logo.setIcon(new javax.swing.ImageIcon("cactuslogo.png")); // NOI18N
		// ajout du logo
		add(logo);
		// positionnement
		logo.setBounds(60, 70, 604, 270);

		/////// D�but //////
		// ici on ajout du texte sur les radioboutons pour savoir � quoi il
		/////// corresponde
		// puis on ajoute un listener
		// on ajoute le radiobouton dans le panel
		// on initialise setActionCommand qui permet quand on utilise un
		/////// getActionCommand
		// de r�cup�rer ce que l'on avais mit dedans ( je vais expliquer plus
		/////// tard son utilit� )
		// puis on postionnement le radiobouton
		// ce sh�ma et exactement le m�me pour tous
		motclef.setText("Mot Clef");
		motclef.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				motclefActionPerformed(evt);
			}
		});
		add(motclef);
		motclef.setActionCommand("motclef");
		motclef.setBounds(50, 350, 90, 30);

		imgrgb.setText("ImageRGB");
		add(imgrgb);
		imgrgb.setActionCommand("imgrgb");
		imgrgb.setBounds(290, 350, 110, 30);

		imgnb.setText("ImageNB");
		add(imgnb);
		imgnb.setActionCommand("imgnb");
		imgnb.setBounds(430, 350, 100, 30);

		file.setText("Fichier");
		add(file);
		file.setActionCommand("file");
		file.setBounds(170, 350, 90, 30);

		domin = new javax.swing.JRadioButton();
		domin.setText("Couleur");
		add(domin);
		domin.setActionCommand("domin");
		domin.setBounds(560, 350, 100, 30);

		////// FIN ////////

		// on rassemble tous les boutons pour �viter que deux d'entre eux soit
		// coch� en m�me temps
		group = new javax.swing.ButtonGroup();
		group.add(imgnb);
		group.add(imgrgb);
		group.add(file);
		group.add(motclef);
		group.add(domin);
		//// FIN ///

		// init background du panel
		carrevert.setBackground(new java.awt.Color(175, 226, 26));
		// layout = null
		carrevert.setLayout(null);

		// ajout de texte sur le bouton de connexion
		connexion.setText("Connexion");
		// r�gle sa taille
		connexion.setPreferredSize(new java.awt.Dimension(75, 23));
		// ajout listener
		connexion.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				connexionActionPerformed(evt);
			}
		});

		// ajout le bouton dans le panel
		carrevert.add(connexion);
		// positionnement le bouton
		connexion.setBounds(420, 20, 130, 30);

		// ici on utilise nomdeco pour afficher l'ID de la personne connecter
		carrevert.add(nomdeco);
		// postionnement
		nomdeco.setBounds(440, 20, 110, 30);
		// et l� on fait en sorte qu'il ne soit pas visible
		nomdeco.setVisible(false);

		// ajout de texte sur le bouton d'inscription
		inscrire.setText("S'inscrire");
		// ajout listener
		inscrire.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				inscrireActionPerformed(evt);
			}
		});
		// ajout dans le panel
		carrevert.add(inscrire);
		// positionnement
		inscrire.setBounds(570, 20, 110, 30);

		// ajout de texte sur le bouton de deconnexion
		deco.setText("Deconnexion");
		// ajout listener
		deco.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				decoActionPerformed(evt);
			}
		});
		// ajout dans le panel
		carrevert.add(deco);
		// positionnement
		deco.setBounds(560, 10, 130, 40);
		// cache le bouton
		deco.setVisible(false);

		// ajout de texte sur le bouton d'Options
		option.setText("Options");
		// ajout listener
		deco.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				optionActionPerformed(evt);
			}
		});
		// cache le bouton
		option.setVisible(false);
		// positionnement
		option.setBounds(30, 20, 100, 30);

		// ajout du carr�e vert dans le panel
		add(carrevert);
		// positionnement
		carrevert.setBounds(0, 0, 720, 61);
	}
	////////////////////////// FIN///////////////////////////////

	public int getType() {
		return type;
	}

	/// ici on g�rer les actions sur la barre de recherche
	private void barsearchKeyPressed(java.awt.event.KeyEvent evt) {
		// TODO add your handling code here:
		// recuperer le code de l'event d�tecter
		int key = evt.getKeyCode();
		// comparer ce code avec le code de la touche entrer
		if (key == KeyEvent.VK_ENTER) {

			// recuperer le texte entrer dans une string
			recherche = barsearch.getText();

			// ici on fait getActionCommand sur le radiobouton qui est selection
			// afin de savoir quels mode de recherche veut faire l'utilisateur
			String selec = group.getSelection().getActionCommand();

			// Switch case qui va en fonction de l String selec faire le choix
			// de la recherche a lancer
			switch (selec) {
			
			////IMPORTANT ////
			/// ici je ne vais d�tailler que le premier cas du Switch case car les autres cas sont similaires 
			// la seule diff�rence vient de la fonction de recherche qui est lancer 
			// recherche par mot clef
			case "motclef":
				
				// lance la recherche par mot clef avec en param�tre la recherche entrer par l'utilisateur
				brmc.rechercheMotClefs(recherche);

				//ici on fait un sleep pour attendre que le programme C �crire les r�sultats dans le fichier texte 
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				this.type = 1;
				
				if (!bdu.listeUtilisateursIsEmpty()) {/// test si BD utilisateur est vide 
					for (int clef : bdu.getlisteUtilisateurs().keySet()) { // passe les utilisateur 1 � 1
						if (bdu.getlisteUtilisateurs().get(clef).selecteProfil(Stock.getLogin(), Stock.getMdp())) { //test si l'utilisateur actuel est connu
							if (bdu.getUtilisateur(Stock.getNumeroUtil()).isConnecte()) {//regarde si il est connecter
								ceh.controlEnregistrerHistoriqueUtilisateur(Stock.getNumeroUtil());// si oui enregistre la recher dans historique
							}
						}
					}
				}
				// pareil que le IF pr�c�dent mais pour les administrateurs
				if (!bda.listeAdminIsEmpty()) {
					for (int clef : bda.getlisteAdmins().keySet()) {
						if (bda.getlisteAdmins().get(clef).selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bda.getAdmin(Stock.getNumeroUtil()).isConnecte()) {
								ceh.controlEnregistrerHistoriqueAdmin(Stock.getNumeroUtil());
							}
						}
					}
				}

				break;
			// recherche par fichier
			case "file":
				this.br.rechercheTI(recherche);

				try {
					Thread.sleep(400);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				this.type = 1;

				if (!bdu.listeUtilisateursIsEmpty()) {
					for (int clef : bdu.getlisteUtilisateurs().keySet()) {
						if (bdu.getlisteUtilisateurs().get(clef).selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bdu.getUtilisateur(Stock.getNumeroUtil()).isConnecte()) {
								ceh.controlEnregistrerHistoriqueUtilisateur(Stock.getNumeroUtil());
							}
						}
					}
				}

				if (!bda.listeAdminIsEmpty()) {
					for (int clef : bda.getlisteAdmins().keySet()) {
						if (bda.getlisteAdmins().get(clef).selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bda.getAdmin(Stock.getNumeroUtil()).isConnecte()) {
								ceh.controlEnregistrerHistoriqueAdmin(Stock.getNumeroUtil());
							}
						}
					}
				}

				break;
			// recherche par image RGB
			case "imgrgb":
				this.br.rechercheTI(recherche);

				try {
					Thread.sleep(300);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				this.type = 2;

				if (!bdu.listeUtilisateursIsEmpty()) {
					for (int clef : bdu.getlisteUtilisateurs().keySet()) {
						if (bdu.getlisteUtilisateurs().get(clef).selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bdu.getUtilisateur(Stock.getNumeroUtil()).isConnecte()) {
								ceh.controlEnregistrerHistoriqueUtilisateur(Stock.getNumeroUtil());
							}
						}
					}
				}

				if (!bda.listeAdminIsEmpty()) {
					for (int clef : bda.getlisteAdmins().keySet()) {
						if (bda.getlisteAdmins().get(clef).selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bda.getAdmin(Stock.getNumeroUtil()).isConnecte()) {
								ceh.controlEnregistrerHistoriqueAdmin(Stock.getNumeroUtil());
							}
						}
					}
				}
				break;
			// recherche par image Noir et Blanc
			case "imgnb":
				this.br.rechercheTI(recherche);

				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				this.type = 3;

				if (!bdu.listeUtilisateursIsEmpty()) {
					for (int clef : bdu.getlisteUtilisateurs().keySet()) {
						if (bdu.getlisteUtilisateurs().get(clef).selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bdu.getUtilisateur(Stock.getNumeroUtil()).isConnecte()) {
								ceh.controlEnregistrerHistoriqueUtilisateur(Stock.getNumeroUtil());
							}
						}
					}
				}

				if (!bda.listeAdminIsEmpty()) {
					for (int clef : bda.getlisteAdmins().keySet()) {
						if (bda.getlisteAdmins().get(clef).selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bda.getAdmin(Stock.getNumeroUtil()).isConnecte()) {
								ceh.controlEnregistrerHistoriqueAdmin(Stock.getNumeroUtil());
							}
						}
					}
				}
				break;

			// recherche par couleur dominante
			case "domin":
				try {
					brc.rechCouleur(recherche);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				this.type = 2;

				if (!bdu.listeUtilisateursIsEmpty()) {
					for (int clef : bdu.getlisteUtilisateurs().keySet()) {
						if (bdu.getlisteUtilisateurs().get(clef).selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bdu.getUtilisateur(Stock.getNumeroUtil()).isConnecte()) {
								ceh.controlEnregistrerHistoriqueUtilisateur(Stock.getNumeroUtil());
							}
						}
					}
				}

				if (!bda.listeAdminIsEmpty()) {
					for (int clef : bda.getlisteAdmins().keySet()) {
						if (bda.getlisteAdmins().get(clef).selecteProfil(Stock.getLogin(), Stock.getMdp())) {
							if (bda.getAdmin(Stock.getNumeroUtil()).isConnecte()) {
								ceh.controlEnregistrerHistoriqueAdmin(Stock.getNumeroUtil());
							}
						}
					}
				}

				break;
			}
		}

	}

	private void decoActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:

		ControlDeconnexion cd = new ControlDeconnexion();
		cd.controlDeconnexion(Stock.getLogin(), Stock.getMdp());

		Stock.setNumeroUtil(-1);
		Stock.setLogin("");
		Stock.setMdp("");

	}

	private void motclefActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void connexionActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void inscrireActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void optionActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	// Variables declaration
	javax.swing.JTextField barsearch;
	javax.swing.JPanel carrevert;
	javax.swing.JButton connexion;
	javax.swing.JRadioButton file;
	javax.swing.JRadioButton imgnb;
	javax.swing.JRadioButton imgrgb;
	javax.swing.JButton inscrire;
	javax.swing.JRadioButton motclef;
	javax.swing.JRadioButton domin;
	javax.swing.JLabel logo;
	javax.swing.ButtonGroup group;
	javax.swing.JButton deco;
	javax.swing.JLabel nomdeco;
	javax.swing.JButton option;
	// End of variables declaration
}
