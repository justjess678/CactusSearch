package vueGraphique;

import model.BDUtilisateur;
import model.Stockage;
import vue.BoundaryConnexion;
import vue.BoundaryCreerProfil;
import control.ControlEnregistrerBD;

public class panelInscrit extends javax.swing.JPanel {

	public panelInscrit() {
		initComponents();
	}

	Stockage Stock = Stockage.getInstance();

	private void initComponents() {

		// initialisation du types de stous les composants
		carrevertinscrit = new javax.swing.JPanel();
		carrebeigeinscrit = new javax.swing.JPanel();
		prenom = new javax.swing.JTextField();
		imgprofil = new javax.swing.JLabel();
		id = new javax.swing.JTextField();
		mdp = new javax.swing.JTextField();
		nom = new javax.swing.JTextField();
		validinscri = new javax.swing.JButton();
		admin = new javax.swing.JButton();

		// initialise le layout = null pour positionner les composants comme on
		// le souhaite
		setLayout(null);

		// cr�ation du carr�e vert
		carrevertinscrit.setBackground(new java.awt.Color(175, 226, 26));
		// initialisation du layout = null
		carrevertinscrit.setLayout(null);
		// ajout du carr�e vert au panel principale
		add(carrevertinscrit);
		// positionnement du carr�e vert dans le panel principale
		carrevertinscrit.setBounds(0, 0, 720, 61);

		// initialisation de la couleur du panel carr�e beige
		carrebeigeinscrit.setBackground(new java.awt.Color(239, 227, 175));
		// init layout = null
		carrebeigeinscrit.setLayout(null);

		// ajout du listener sur le bouton valider l'inscription
		validinscri.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				validinscriActionPerformed(evt);
			}
		});

		// ajout de texte dans le champ de texte prenom
		prenom.setText("prenom");
		// ajout du listener sur le champ de texte prenom
		prenom.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				prenomActionPerformed(evt);
			}
		});
		// ajout du champ de de texte prenom dans le panel
		carrebeigeinscrit.add(prenom);
		// positionnement de prenom dans le panel
		prenom.setBounds(170, 290, 140, 30);

		// init de la couleur du bouton Devenir admin
		admin.setBackground(new java.awt.Color(240, 0, 0));
		// ajout de texte sur le bouton
		admin.setText("Devenir Admin");
		// ajout du bouton dans le panel carr�e vert
		carrevertinscrit.add(admin);
		// positonnement du bouton dans le panel
		admin.setBounds(280, 10, 160, 40);

		/// la partie image profil �tait une id�e d'amelioration afin que
		/// l'utilisateur puisse personnaliser son compte
		// ajout d'un icon sur le label
		imgprofil.setIcon(new javax.swing.ImageIcon("imageprofil.png")); // NOI18N
		// ajout de image profil sur le panel carr�e beige
		carrebeigeinscrit.add(imgprofil);
		// positionnement de l'image profil
		imgprofil.setBounds(280, 90, 150, 160);

		// ajout de texte dans le champ de texte ID
		id.setText("identifiant");
		// ajout d'un listener sur le champ de texte
		id.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				idActionPerformed(evt);
			}
		});
		// ajout de ID dans le panel carr�e beige
		carrebeigeinscrit.add(id);
		// pisitionnement de ID dans le panel
		id.setBounds(170, 360, 140, 30);

		// ajout de texte dans le champ de texte MDP
		mdp.setText("motdepasse");
		// ajout d'un listener sur le champ de MDP
		mdp.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				mdpActionPerformed(evt);
			}
		});
		// ajout de MDP dans le panel carr�e beige
		carrebeigeinscrit.add(mdp);
		// positionnement de MDP dans le panel
		mdp.setBounds(390, 360, 140, 30);

		// ajout de texte dans le champ de texte nom
		nom.setText("nom");
		// ajout listener
		nom.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				nomActionPerformed(evt);
			}
		});
		// ajout dans le panel
		carrebeigeinscrit.add(nom);
		// positionnement
		nom.setBounds(390, 290, 140, 30);

		// ajout de texte sur le bouton
		validinscri.setText("Valider");
		// ajout bouton dans le panel
		carrebeigeinscrit.add(validinscri);
		// positionnement
		validinscri.setBounds(280, 410, 140, 40);
		// ajout carr�e beige dans le panel principale
		add(carrebeigeinscrit);
		// positonnement
		carrebeigeinscrit.setBounds(0, 0, 720, 461);
	}

	///// Ici nous enregistrons les utilisateurs dans la base de donn�e afin
	///// qu'a chaque red�marrage du moteur de recherche tous les comptes soit
	///// m�moriser///////
	private void validinscriActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		// cr�ation de string pour stocker
		String firstname, lastname, password, ident;
		//cr�ation du boundary creer profil 
		BoundaryCreerProfil bcp = new BoundaryCreerProfil();
		//cr�ation du control enregistrer bd
		ControlEnregistrerBD ceBD = new ControlEnregistrerBD();
		//cr�ation du boundary  connexion
		BoundaryConnexion bc = new BoundaryConnexion();

		// ici on stock tous ce qui est taper dans les champs de textes
		ident = id.getText();
		password = mdp.getText();
		firstname = prenom.getText();
		lastname = nom.getText();

		// creer le profil utilisateur 
		bcp.creerProfilUtilisateur(ident, password, lastname, firstname);
		
		// ici on stock le numero de l'utilisateur
		Stock.setNumeroUtil(bc.connexion(ident, password));
		//son login
		Stock.setLogin(ident);
		// son mdp
		Stock.setMdp(password);

		//ajout de texte dans tous les champs qui sont � remplir
		id.setText("identifiant");
		nom.setText("nom");
		prenom.setText("prenom");
		mdp.setText("motdepasse");
		
		// control si tous est bien enregistrer
		ceBD.controlEnregistrerBD();
	}

	/////////////// FIN ////////////////////////

	//// fonction qui permette d'effectuer une action si un event est apparut
	//// sur les champ de textes ici nous ne nous en servons pas mais les
	//// laissons
	// si jamais un jour nous en avons besoins
	private void nomActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void prenomActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void idActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void mdpActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}
	///// FIN//////

	// Variables declaration
	javax.swing.JPanel carrebeigeinscrit;
	javax.swing.JPanel carrevertinscrit;
	javax.swing.JTextField id;
	javax.swing.JLabel imgprofil;
	javax.swing.JTextField mdp;
	javax.swing.JTextField nom;
	javax.swing.JTextField prenom;
	javax.swing.JButton validinscri;
	javax.swing.JButton admin;
	// End of variables declaration
}
