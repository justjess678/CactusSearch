package vueGraphique;

import model.Stockage;
import vue.BoundaryConnexion;
import vue.BoundaryCreerProfil;
import control.ControlEnregistrerBD;

public class panelAdmin extends javax.swing.JPanel {
	public panelAdmin() {
		initComponents();
	}

	Stockage Stock = Stockage.getInstance();

	private void initComponents() {
		
		// initialisation du types de stous les composants
		carrevertinscrit = new javax.swing.JPanel();
		carrebeigeinscrit = new javax.swing.JPanel();
		prenom = new javax.swing.JTextField();
		imgprofil2 = new javax.swing.JLabel();
		mdpAdmin = new javax.swing.JTextField();
		mdp = new javax.swing.JTextField();
		nom = new javax.swing.JTextField();
		validinscri = new javax.swing.JButton();
		id = new javax.swing.JTextField();

		// initialise le layout = null pour positionner les composants comme on
		// le souhaite	
		setLayout(null);

		// cr�ation du carr�e vert
		carrevertinscrit.setBackground(new java.awt.Color(175, 226, 26));
		// initialisation du layout = null
		carrevertinscrit.setLayout(null);
		// ajout du carr�e vert au panel principale
		add(carrevertinscrit);
		// positionnement du carr�e vert dans le panel principale
		carrevertinscrit.setBounds(0, 0, 720, 61);

		// initialisation de la couleur du panel carr�e beige
		carrebeigeinscrit.setBackground(new java.awt.Color(239, 227, 175));
		// init layout = null
		carrebeigeinscrit.setLayout(null);

		// ajout du listener sur le bouton valider l'inscription
		validinscri.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				validinscriActionPerformed(evt);
			}
		});

		// ajout de texte dans le champ de texte prenom
		prenom.setText("prenom");
		// ajout du listener sur le champ de texte prenom
		prenom.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				prenomActionPerformed(evt);
			}
		});
		// ajout du champ de de texte prenom dans le panel
		carrebeigeinscrit.add(prenom);
		// positionnement de prenom dans le panel
		prenom.setBounds(80, 280, 150, 40);

		/// la partie image profil �tait une id�e d'amelioration afin que
		/// l'utilisateur puisse personnaliser son compte
		// ajout d'un icon sur le label
		imgprofil2.setIcon(new javax.swing.ImageIcon("imageprofil.png")); // NOI18N
		// ajout de image profil sur le panel carr�e beige
		carrebeigeinscrit.add(imgprofil2);
		// positionnement de l'image profil
		imgprofil2.setBounds(280, 90, 150, 160);

		// init police et taille du texte 
		mdpAdmin.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
		// ajout de texte dans le champ de texte MDPadmin
		mdpAdmin.setText("Mdp Admin");
		// ajout d'un listener sur le champ de MDPadmin
		mdpAdmin.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				mdpAdminActionPerformed(evt);
			}
		});
		// ajout de DMPAdmin dans le panel carr�e beige
		carrebeigeinscrit.add(mdpAdmin);
		// positionnement 
		mdpAdmin.setBounds(410, 350, 180, 40);

		// init police et taille du texte 
		mdp.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
		// ajout de texte dans le champ de texte MDP
		mdp.setText("motdepasse");
		// ajout d'un listener sur le champ de MDP
		mdp.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				mdpActionPerformed(evt);
			}
		});
		// ajout de MDP dans le panel carr�e beige
		carrebeigeinscrit.add(mdp);
		// positionnement de MDP dans le panel
		mdp.setBounds(160, 350, 150, 40);

		// init police et taille du texte 
		nom.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
		// ajout de texte dans le champ de texte nom
		nom.setText("nom");
		// ajout listener
		nom.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				nomActionPerformed(evt);
			}
		});
		// ajout dans le panel
		carrebeigeinscrit.add(nom);
		// positionnement
		nom.setBounds(290, 280, 150, 40);

		// ajout de texte sur le bouton
		validinscri.setText("Valider");
		// ajout bouton dans le panel
		carrebeigeinscrit.add(validinscri);
		// positionnement
		validinscri.setBounds(280, 410, 140, 40);
		
		// init police et taille du texte 
		id.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
		// ajout de texte dans le champ de texte ID
		id.setText("identifiant");
		// ajout d'un listener sur le champ de texte
		id.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				idActionPerformed(evt);
			}
		});
		// ajout de ID dans le panel carr�e beige
		carrebeigeinscrit.add(id);
		// pisitionnement de ID dans le panel
		id.setBounds(490, 280, 150, 40);

		add(carrebeigeinscrit);
		// positonnement
		carrebeigeinscrit.setBounds(0, 0, 720, 461);
	}
	///// Ici nous enregistrons les admins dans la base de donn�e afin
	///// qu'a chaque red�marrage du moteur de recherche tous les comptes soit
	///// m�moriser///////
	private void validinscriActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		// cr�ation de string pour stocker
		String firstname, lastname, password, ident, supermdp;
		//cr�ation du boundary creer profil 
		BoundaryCreerProfil bcp = new BoundaryCreerProfil();
		//cr�ation du control enregistrer bd
		ControlEnregistrerBD ceBD = new ControlEnregistrerBD();
		//cr�ation du boundary  connexion
		BoundaryConnexion bc = new BoundaryConnexion();

		// ici on stock tous ce qui est taper dans les champs de textes
		ident = id.getText();
		password = mdp.getText();
		firstname = prenom.getText();
		lastname = nom.getText();
		supermdp = mdpAdmin.getText();
		
		//cr�er le profil admin
		bcp.creerProfilAdmin(ident, password, lastname, firstname, supermdp);
		
		// ici on stock le numero de l'admin 
		Stock.setNumeroUtil(bc.connexion(ident, password));
		// son login
		Stock.setLogin(ident);
		// son mdp
		Stock.setMdp(password);

		//ajout de texte dans tous les champs qui sont � remplir
		id.setText("identifiant");
		nom.setText("nom");
		prenom.setText("prenom");
		mdp.setText("motdepasse");
		mdpAdmin.setText("mdpAdmin");
		
		// control si tous est bien enregistrer
		ceBD.controlEnregistrerBD();

	}
	//// FIN/////

	//// fonction qui permette d'effectuer une action si un event est apparut
	//// sur les champ de textes ici nous ne nous en servons pas mais les
	//// laissons
	// si jamais un jour nous en avons besoins

	private void nomActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void mdpAdminActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void prenomActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void idActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void mdpActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}
	/// FIN////

	// Variables declaration
	javax.swing.JPanel carrebeigeinscrit;
	javax.swing.JPanel carrevertinscrit;
	javax.swing.JTextField id;
	javax.swing.JLabel imgprofil2;
	javax.swing.JTextField mdp;
	javax.swing.JTextField nom;
	javax.swing.JTextField prenom;
	javax.swing.JButton validinscri;
	javax.swing.JTextField mdpAdmin;
	// End of variables declaration
}
