package vueGraphique;

import model.BDUtilisateur;
import control.ControlChargerBD;

public class panelCharg extends javax.swing.JPanel {

	public panelCharg() {
		initComponents();
	}

	@SuppressWarnings("unchecked")
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {
		/// Ce panel dit de chargement nous sert � charger la base de donn�es
		// des utilisteurs et des admins
		ControlChargerBD ccBD = new ControlChargerBD();
		
		// initialisation du types de tous les composants du panel
		logo = new javax.swing.JLabel();
		charge = new javax.swing.JButton();

		// on change la couleur du panel
		setBackground(new java.awt.Color(239, 227, 175));
		// on r�gle la taille du panel
		setPreferredSize(new java.awt.Dimension(720, 480));
		//init du layout = null 
		setLayout(null);

		// ajout un logo  charger depuis la sources du programme
		logo.setIcon(new javax.swing.ImageIcon("cactuslogo.png")); // NOI18N
		// ajout du logo sur le panel
		add(logo);
		// postionnement 
		logo.setBounds(60, 70, 604, 270);
		
		// on rend le bouton transparent
		charge.setOpaque(false);
		// enlevons sa couleur
		charge.setContentAreaFilled(false);
		// enlevons les bords
		charge.setBorderPainted(false);
		// et le positionnons
		charge.setBounds(0, 0, 720, 480);
		// charge les BD 
		ccBD.controlChargerBD();
		//ajout du bouton
		add(charge);
		
	}// </editor-fold>

	// Variables declaration 
	javax.swing.JLabel logo;
	javax.swing.JButton charge;
	// End of variables declaration
}
