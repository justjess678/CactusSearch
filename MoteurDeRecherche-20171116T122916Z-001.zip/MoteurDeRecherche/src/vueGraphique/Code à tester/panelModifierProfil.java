package vueGraphique;

import model.BDAdmin;
import model.BDUtilisateur;
import model.Stockage;
import vue.BoundaryConnexion;
import vue.BoundaryModifierProfil;
import control.ControlEnregistrerBD;

public class panelModifierProfil extends javax.swing.JPanel {

	public panelModifierProfil() {
		initComponents();
	}

	Stockage Stock = Stockage.getInstance();
	BDUtilisateur bdu = BDUtilisateur.getInstance();
	BDAdmin bda = BDAdmin.getInstance();

	private void initComponents() {

		// initialisation du types de tous les composants du panel
		carrevertinscrit = new javax.swing.JPanel();
		carrebeigeinscrit = new javax.swing.JPanel();
		prenom = new javax.swing.JTextField();
		imgprofil = new javax.swing.JLabel();
		id = new javax.swing.JTextField();
		mdp = new javax.swing.JTextField();
		nom = new javax.swing.JTextField();
		validmodif = new javax.swing.JButton();

		//init du layout = null 
		setLayout(null);
		
		// initialisation de la couleur du panel vert et le layout = null aussi
		carrevertinscrit.setBackground(new java.awt.Color(175, 226, 26));
		carrevertinscrit.setLayout(null);
		// ajout du carr�e vert sur le panel principale
		add(carrevertinscrit);
		// positionnement du carr�e vert
		carrevertinscrit.setBounds(0, 0, 720, 61);

		// initialisation de la couleur du panel carr�e beige
		carrebeigeinscrit.setBackground(new java.awt.Color(239, 227, 175));
		// init layout = null
		carrebeigeinscrit.setLayout(null);

		// ajout du listener sur le bouton valider modification
		validmodif.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				validmodifActionPerformed(evt);
			}
		});

		
		//ajout de texte dans le champ de texte prenom
		prenom.setText("prenom");
		// ajout du listener sur le champ de texte prenom
		prenom.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				prenomActionPerformed(evt);
			}
		});
		//ajout du champ de de texte prenom dans le panel 
		carrebeigeinscrit.add(prenom);
		// positionnement de prenom dans le panel 
		prenom.setBounds(170, 290, 140, 30);

		/// la partie image profil �tait une id�e d'amelioration afin que l'utilisateur puisse personnaliser son compte
		//ajout d'un icon sur le label 
		imgprofil.setIcon(new javax.swing.ImageIcon("imageprofil.png")); // NOI18N
		//ajout de image profil sur le panel carr�e beige
		carrebeigeinscrit.add(imgprofil);
		// positionnement de l'image profil
		imgprofil.setBounds(280, 90, 150, 160);

		// ajout de texte dans le champ de texte ID
		id.setText("identifiant");
		//ajout d'un listener sur le champ de texte
		id.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				idActionPerformed(evt);
			}
		});
		//ajout de ID dans le panel carr�e beige
		carrebeigeinscrit.add(id);
		//pisitionnement de ID dans le panel
		id.setBounds(170, 360, 140, 30);

		// ajout de texte dans le champ de texte MDP
		mdp.setText("motdepasse");
		//ajout d'un listener sur le champ de MDP
		mdp.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				mdpActionPerformed(evt);
			}
		});
		//ajout de MDP dans le panel carr�e beige
		carrebeigeinscrit.add(mdp);
		//positionnement de MDP dans le panel
		mdp.setBounds(390, 360, 140, 30);

		// ajout de texte dans le champ de texte nom
		nom.setText("nom");
		//ajout listener
		nom.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				nomActionPerformed(evt);
			}
		});
		//ajout dans le panel
		carrebeigeinscrit.add(nom);
		//positionnement
		nom.setBounds(390, 290, 140, 30);

		// ajout de texte sur le bouton
		validmodif.setText("Modifier Profil");
		// ajout du bouton dans le panel
		carrebeigeinscrit.add(validmodif);
		// positionnemtn du bouton dans le panel
		validmodif.setBounds(280, 410, 140, 40);

		// ajout de crr�e beige dans le panel principale
		add(carrebeigeinscrit);
		// positionnement
		carrebeigeinscrit.setBounds(0, 0, 720, 461);
		
	}// </editor-fold>

	///// Ici nous modifions les ID/MDP/prenom/nom de l'utilisateur connecter 
	/////dans la base de donn�e 
	private void validmodifActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
		BoundaryModifierProfil bmp = new BoundaryModifierProfil();
		ControlEnregistrerBD ceBD = new ControlEnregistrerBD();
		BoundaryConnexion bc = new BoundaryConnexion();

		String firstname, lastname, password, ident;
		ident = id.getText();
		password = mdp.getText();
		firstname = prenom.getText();
		lastname = nom.getText();

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		for (int key : bdu.getlisteUtilisateurs().keySet()) {
			if (bdu.getlisteUtilisateurs().get(key)
					.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
				
				
				bmp.modifierProfilUtilisateur(ident, password, lastname, firstname,
						Stock.getNumeroUtil());
				ceBD.controlEnregistrerBD();
				// Stock.setNumeroUtil(bc.connexion(ident, password));
				Stock.setLogin(ident);
				Stock.setMdp(password);
			}

		}
		for (int key1 : bda.getlisteAdmins().keySet()) {

			if (bda.getlisteAdmins().get(key1)
					.selecteProfil(Stock.getLogin(), Stock.getMdp())) {
				
				bmp.modifierProfilAdmin(ident, password, lastname, firstname,
						Stock.getNumeroUtil());
				ceBD.controlEnregistrerBD();
				// Stock.setNumeroUtil(bc.connexion(ident, password));
				Stock.setLogin(ident);
				Stock.setMdp(password);
			}

		}
		id.setText("identifiant");
		nom.setText("nom");
		prenom.setText("prenom");
		mdp.setText("motdepasse");
	}
	////fonction qui permette d'effectuer une action si un event est apparut
	//// sur les champ de textes ici nous ne nous en servons pas mais les
	//// laissons
	// si jamais un jour nous en avons besoins
	private void nomActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void prenomActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void idActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void mdpActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}
	///FIN////
	// Variables declaration 
	javax.swing.JPanel carrebeigeinscrit;
	javax.swing.JPanel carrevertinscrit;
	javax.swing.JTextField id;
	javax.swing.JLabel imgprofil;
	javax.swing.JTextField mdp;
	javax.swing.JTextField nom;
	javax.swing.JTextField prenom;
	javax.swing.JButton validmodif;

	// End of variables declaration
}