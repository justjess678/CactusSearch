package vueGraphique;

import vue.BoundaryConnexion;
import model.BDUtilisateur;
import model.Stockage;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

public class panelConnexion extends javax.swing.JPanel {

	// instancier Stockage 
	Stockage Stock = Stockage.getInstance();

	public panelConnexion() {
		initComponents();
	}

	private void initComponents() {

		// initialisation du types des composants du panel
		rechPanel = new javax.swing.JPanel();
		textFieldLogin = new javax.swing.JTextField();
		jPasswordField1 = new javax.swing.JPasswordField();
		labelLogin = new javax.swing.JLabel();
		labelMdp = new javax.swing.JLabel();
		boutonConnexion = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();
		carrevert = new javax.swing.JPanel();
		
		// initalisation de la couleur du panel principal
		setBackground(new java.awt.Color(239, 227, 175));

		// initalisation de la couleur du panel rechPanel
		rechPanel.setBackground(new java.awt.Color(175, 226, 26));

		// ici on regroupe rechPanel dans un groupLayout
		javax.swing.GroupLayout rechPanelLayout = new javax.swing.GroupLayout(
				rechPanel);
		rechPanel.setLayout(rechPanelLayout);

		//ajout d'un listener sur le champ de texte du login 
		textFieldLogin.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				textFieldLoginActionPerformed(evt);
			}
		});

		// initialisation de la police et de la taille des caract�res pour Login et Mot de Passe
		labelLogin.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
		labelLogin.setText("Login");

		labelMdp.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
		labelMdp.setText("Mot de Passe");

		// initialisation de la police et de la taille des caract�res pour Connexion
		// ajout d'un listener sur le bouton connexion 
		boutonConnexion.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
		boutonConnexion.setText("Connexion");
		boutonConnexion.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				boutonConnexionActionPerformed(evt);
			}
		});
		
		// initialisation de la police et de la taille des caract�res pour Connexion
		jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
		jLabel1.setText("Connexion");
		
		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
		this.setLayout(layout);
		layout.setHorizontalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addComponent(rechPanel, javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				.addGroup(
						layout.createSequentialGroup()
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING)
												.addGroup(
														layout.createSequentialGroup()
																.addGap(142,
																		142,
																		142)
																.addGroup(
																		layout.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING,
																				false)
																				.addComponent(
																						labelLogin,
																						javax.swing.GroupLayout.DEFAULT_SIZE,
																						javax.swing.GroupLayout.DEFAULT_SIZE,
																						Short.MAX_VALUE)
																				.addComponent(
																						labelMdp))
																.addGap(34, 34,
																		34)
																.addGroup(
																		layout.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING,
																				false)
																				.addComponent(
																						jPasswordField1,
																						javax.swing.GroupLayout.DEFAULT_SIZE,
																						300,
																						Short.MAX_VALUE)
																				.addComponent(
																						textFieldLogin)))
												.addGroup(
														layout.createSequentialGroup()
																.addGap(298,
																		298,
																		298)
																.addComponent(
																		boutonConnexion,
																		javax.swing.GroupLayout.PREFERRED_SIZE,
																		149,
																		javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addContainerGap(139, Short.MAX_VALUE))
				.addGroup(
						javax.swing.GroupLayout.Alignment.TRAILING,
						layout.createSequentialGroup()
								.addGap(0, 0, Short.MAX_VALUE)
								.addComponent(jLabel1).addGap(263, 263, 263)));
		layout.setVerticalGroup(layout
				.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(
						layout.createSequentialGroup()
								.addComponent(rechPanel,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										javax.swing.GroupLayout.DEFAULT_SIZE,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(27, 27, 27)
								.addComponent(jLabel1,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										50,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addGap(41, 41, 41)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.LEADING,
												false)
												.addComponent(
														labelLogin,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														javax.swing.GroupLayout.DEFAULT_SIZE,
														Short.MAX_VALUE)
												.addComponent(
														textFieldLogin,
														javax.swing.GroupLayout.PREFERRED_SIZE,
														40,
														javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGap(72, 72, 72)
								.addGroup(
										layout.createParallelGroup(
												javax.swing.GroupLayout.Alignment.TRAILING)
												.addComponent(
														labelMdp,
														javax.swing.GroupLayout.PREFERRED_SIZE,
														40,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(
														jPasswordField1,
														javax.swing.GroupLayout.PREFERRED_SIZE,
														40,
														javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGap(53, 53, 53)
								.addComponent(boutonConnexion,
										javax.swing.GroupLayout.PREFERRED_SIZE,
										40,
										javax.swing.GroupLayout.PREFERRED_SIZE)
								.addContainerGap(65, Short.MAX_VALUE)));
	}// </editor-fold>//GEN-END:initComponents

	// m�me code que barsearch
	private void inputRechercheActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_inputRechercheActionPerformed
		// TODO add your handling code here:
	}// GEN-LAST:event_inputRechercheActionPerformed

	// lancer recherche
	private void boutonRechercheActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_boutonRechercheActionPerformed
		// TODO add your handling code here:
		// ////////////// IMPORTANT ICI LANCER LA RECHERCHE
		// ///////////////////////////
	}// GEN-LAST:event_boutonRechercheActionPerformed

	// recupere les login et mdp au moment du clique sur le boutton connexion et
	// tester dans la bdclient
	private void textFieldLoginActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_textFieldLoginActionPerformed
		// TODO add your handling code here:
	}// GEN-LAST:event_textFieldLoginActionPerformed

	// lancer un test pour voir si le client et deja inscrit dans la bdclient si
	// oui le connecter
	@SuppressWarnings("deprecation")
	private void boutonConnexionActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_boutonConnexionActionPerformed
		// TODO add your handling code here:
		BoundaryConnexion bc = new BoundaryConnexion();
		String password, ident;
		BDUtilisateur bdu = BDUtilisateur.getInstance();
		
		ident = textFieldLogin.getText();
		password = jPasswordField1.getText();

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
		Stock.setNumeroUtil(bc.connexion(ident, password));
		Stock.setLogin(ident);
		Stock.setMdp(password);
		
		jPasswordField1.setText("");
		textFieldLogin.setText("");
		

	}// GEN-LAST:event_boutonConnexionActionPerformed

	// recupere le type de recherche voir avec Jessica comment marche le combo
	private void comboTypeRechActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_comboTypeRechActionPerformed
		// TODO add your handling code here:
	}// GEN-LAST:event_comboTypeRechActionPerformed

	// Variables declaration - do not modify//GEN-BEGIN:variables
	javax.swing.JButton boutonConnexion;
	javax.swing.JLabel jLabel1;
	javax.swing.JPasswordField jPasswordField1;
	javax.swing.JLabel labelLogin;
	javax.swing.JLabel labelMdp;
	javax.swing.JPanel rechPanel;
	javax.swing.JPanel carrevert;
	javax.swing.JTextField textFieldLogin;
	// End of variables declaration//GEN-END:variables
}
