package control;

import model.Admin;
import model.BDAdmin;
import model.BDUtilisateur;
import model.Utilisateur;

public class ControlCreerProfil {
	BDUtilisateur bdUtilisateur = BDUtilisateur.getInstance();
	BDAdmin bdAdmin = BDAdmin.getInstance();
	
	public int creerProfilUtilisateur(String login, String nom, String prenom, String mdp){;
			Utilisateur u = new Utilisateur();
			u.creerProfilUtilisateur(login, mdp, nom, prenom);
			this.bdUtilisateur.ajouterUtilisateur(u);
			return 1;
	}
			
	public int creerProfilAdmin(String login, String nom, String prenom, String mdp){
			Admin a = new Admin();
			a.creerProfilAdmin(login, mdp, nom, prenom);
			this.bdAdmin.ajouterAdmin(a);
			return 1;	
		}
}

