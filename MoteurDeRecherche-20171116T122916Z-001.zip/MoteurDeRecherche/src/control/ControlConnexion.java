package control;

import model.BDAdmin;
import model.BDUtilisateur;

public class ControlConnexion {
	
	BDUtilisateur bdUtilisateur = BDUtilisateur.getInstance();
	BDAdmin bdAdmin = BDAdmin.getInstance();
	
	public int controlConnexion(String login, String mdp){
		
		int ackAdmin = bdAdmin.connexionAdmin(login, mdp);
		int ackUtil = bdUtilisateur.connexionUtilisateur(login, mdp);


		if(  ackUtil > 0)
			return ackUtil;
		else if( ackAdmin > 0)
			return ackAdmin;
		else
			return -1;
		
	}

}
