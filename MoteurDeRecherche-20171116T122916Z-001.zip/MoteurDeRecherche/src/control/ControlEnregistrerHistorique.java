package control;

import model.BDAdmin;
import model.BDUtilisateur;
import model.EnregistrerHistoriqueAdmin;
import model.EnregistrerHistoriqueUtilisateur;
//modifi�
public class ControlEnregistrerHistorique {
	
	EnregistrerHistoriqueUtilisateur ehu = new EnregistrerHistoriqueUtilisateur();
	EnregistrerHistoriqueAdmin eha = new EnregistrerHistoriqueAdmin();
	BDUtilisateur bdu = BDUtilisateur.getInstance();
	BDAdmin bda = BDAdmin.getInstance();
	
	public void controlEnregistrerHistoriqueUtilisateur(int numeroUtilisateur){
		if (bdu.getUtilisateur(numeroUtilisateur).isConnecte() ){
			ehu.enregistrerHistoriqueUtilisateur(numeroUtilisateur);
		}
	}
	
	
	public void controlEnregistrerHistoriqueAdmin(int numeroUtilisateur){
		if (bda.getAdmin(numeroUtilisateur).isConnecte()){
			eha.enregistrerHistoriqueAdmin(numeroUtilisateur);
		}
	}
}
