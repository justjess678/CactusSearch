package control;

import model.BDAdmin;
import model.BDUtilisateur;

public class ControlEnregistrerBD {
	
	BDUtilisateur bde = BDUtilisateur.getInstance();
	BDAdmin bda = BDAdmin.getInstance();
	
	public void controlEnregistrerBD(){
	
		bde.enregistrerUtilisateur();
		bda.enregistrerAdmin();
		
	}

}
