package control;



import model.Admin;
import model.BDAdmin;
import model.BDUtilisateur;
import model.Utilisateur;

public class ControlModifierProfil {
	BDUtilisateur bdUtilisateur = BDUtilisateur.getInstance();
	BDAdmin bdAdmin = BDAdmin.getInstance();

	public int modifierProfilUtilisateur(String login, String nom,
			String prenom, String mdp, int numClient){
			Utilisateur u = this.bdUtilisateur.getUtilisateur(numClient);
			u.setLogin(login);
			u.setMdp(mdp);
			u.setNom(nom);
			u.setPrenom(prenom);
			this.bdUtilisateur.majUtilisateur(u, numClient);
			return 1;
	}
			
	public int modifierProfilAdmin (String login, String nom,String prenom, String mdp, int numClient){
			Admin a = this.bdAdmin.getAdmin(numClient);
			a.setLogin(login);
			a.setMdp(mdp);
			a.setNom(nom);
			a.setPrenom(prenom);
			this.bdAdmin.majAdmin(a, numClient);
			return 1;
		}

	public void supprimerUtilisateur( int numClient) {
		this.bdUtilisateur.supprimerUtilisateur(numClient);
	}

	public void supprimerAdmin(int numClient) {
		this.bdAdmin.supprimerAdmin(numClient);
	}
		

}
