package control;

import java.util.ArrayList;
import model.AfficherResultat;

/** Clement Guerin et Nicolas Mallent **/

public class ControlAfficherResultat {
	
	    //declaration
		private ArrayList<String> resu = new ArrayList<String>();
		AfficherResultat recupResultat = new AfficherResultat();

		// Method
		public ArrayList<String> envoieDataControl() {
            /** appel de la methode afficherResultat **/
			resu = this.recupResultat.afficherResultat();
			return this.resu;
		}

        /** Methode pour vérifier que l'arrayList est vide ou pas **/
		public boolean resuEstVide(ArrayList<String> resu) {
			if (resu.isEmpty()) {
				return true;
			} else {
				return false;
			}
		}

}
