package control;

import java.util.ArrayList;

import model.BDAdmin;
import model.BDUtilisateur;
import model.VisualiserHistorique;

public class ControlVisualiserHistorique {
	
	VisualiserHistorique vh = new VisualiserHistorique();
	BDUtilisateur bdu = BDUtilisateur.getInstance();
	BDAdmin bda = BDAdmin.getInstance();
	
	public ArrayList<String> controlVisualiserHistoriqueUtilisateur(int numeroUtilisateur){
		ArrayList<String> histo = new ArrayList<String>();
		
		if (bdu.getUtilisateur(numeroUtilisateur).isConnecte() ){
		histo = vh.visulaiserHistoriqueUtilisateur(numeroUtilisateur);
		}
		return histo;
	}
	
	public ArrayList<String> controlVisualiserHistoriqueAdmin(int numeroUtilisateur){
		ArrayList<String> histo = new ArrayList<String>();
		
		if ( bda.getAdmin(numeroUtilisateur).isConnecte()){
		histo = vh.visulaiserHistoriqueAdmin(numeroUtilisateur);
		}
		return histo;
	}

}
