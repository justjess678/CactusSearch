package control;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import model.RechercheCouleur;

public class ControlRechercheCouleur {
	ArrayList<String> Resultat = new ArrayList<String>();

	public void controlRechercheCouleur(String couleur)
			throws IOException {
			    
	    /** On recupere dans une ArrayList les resultat de la recherche par couleur dominante**/
		Resultat = RechercheCouleur.rechercheCouleur(couleur);
		
		//ecrire dans resultat.txt les fichiers de Resultat
		File f = new File(
				"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/resultat.txt");
				
		/** On supprime et recrée le fichier resultat.txt pour pas ecrire à la suite a chaque recherche successive **/
		f.delete();
		try {
			f.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated
			e1.printStackTrace();
		}
		
		/** Si Resultat est vide: On fait rien
		Sinon on ecrit dans resultat.txt les resultats de la recherche, contenu dans l'ArrayList
		**/
		if (Resultat == null) {
			System.out.println("Il n'y a pas de résultat pour cette couleur");
		} else
			for(int i=0;i<Resultat.size();i++){
				try (FileWriter writer = new FileWriter(f, true)) { 
		            
					writer.write(Resultat.get(i));
		            writer.write("\r\n");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	}
}
