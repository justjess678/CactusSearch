package control;

import java.util.ArrayList;

import model.VisualiserBD;

public class ControlVisualiserBD {
	
	VisualiserBD vbd = new VisualiserBD();
	
	public ArrayList<String> controlVisualiserBDUtilisateur(){
		ArrayList<String> bd = new ArrayList<String>();
		bd = vbd.visulaiserBDUtilisateur();
		return bd;
	}
	
	public ArrayList<String> controlVisualiserBDAdmin(){
		ArrayList<String> bd = new ArrayList<String>();
		bd = vbd.visulaiserBDAdmin();
		return bd;
	}

}
