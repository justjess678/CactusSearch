package control;

import java.io.IOException;
import model.Recherche;

public class ControlRecherche {

	public void controlRecherche(String chemin) throws IOException {
        /** Pas de control particulier pour lancer la recherche, tout le monde y a accés.
         * On vérifie quand meme que le chemin n'est pas vide
        **/
        if(chemin.equals("")){
            System.out.println("Veuillez rentrer un chemin");
        }else{
        	Recherche.recherche(chemin);
        }
	
	}
}
