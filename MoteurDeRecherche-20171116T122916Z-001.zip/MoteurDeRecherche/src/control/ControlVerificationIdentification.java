package control;

import model.Admin;
import model.BDAdmin;
import model.BDUtilisateur;
import model.ProfilClient;
import model.Utilisateur;

public class ControlVerificationIdentification {
	BDUtilisateur bdUtilisateur = BDUtilisateur.getInstance();
	BDAdmin bdAdmin = BDAdmin.getInstance();

	public boolean verificationIdentification(
			ProfilClient profilClient, int numeroProfil) {
		switch (profilClient) {
		case UTILISATEUR:
			if(bdUtilisateur.listeUtilisateursIsEmpty()){
				return false;
			}
			Utilisateur u = bdUtilisateur.getUtilisateur(numeroProfil);
			return u.isConnecte();
		case ADMIN:
			if(bdAdmin.listeAdminIsEmpty()){
				return false;
			}
			Admin a = bdAdmin.getAdmin(numeroProfil);
			return a.isConnecte();
		default:
			return false;
		}
	}


}
