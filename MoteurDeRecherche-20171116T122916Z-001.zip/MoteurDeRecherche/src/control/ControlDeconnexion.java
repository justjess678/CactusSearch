package control;

import model.BDAdmin;
import model.BDUtilisateur;

public class ControlDeconnexion {
	BDUtilisateur bdUtilisateur = BDUtilisateur.getInstance();
	BDAdmin bdAdmin = BDAdmin.getInstance();
	
	public void controlDeconnexion(String login, String mdp){
		
		bdUtilisateur.deconnexionUtilisateur(login,mdp);
		bdAdmin.deconnexionAdmin(login, mdp);

	}
	
}
