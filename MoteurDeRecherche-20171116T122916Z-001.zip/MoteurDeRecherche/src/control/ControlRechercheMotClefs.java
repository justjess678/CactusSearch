package control;

import java.io.IOException;
import java.util.ArrayList;

import model.DifferenceRecherche;
import model.PlusOuMoins;
import model.RechercheMotClefs;
import model.RechercheMotClefsInv;

/** Auteur: Nicolas Mallent **/
public class ControlRechercheMotClefs {
 
    /** Declaration **/
	PlusOuMoins pOM = new PlusOuMoins();
	DifferenceRecherche dR = new DifferenceRecherche();
	RechercheMotClefs rmc = new RechercheMotClefs();
	RechercheMotClefsInv ri = new RechercheMotClefsInv();
	ArrayList<String> Resultat = new ArrayList<String>();
	
	public void rechercheMotClefs(String recherche){

        /** On recupere avec la methode un string avec les mots clefs de la recherche (ex: +qqch -autre chose ...) **/
        /** 1ere etape: on crée un ArrayList avec dans la case 0 les mots clefs en positifs
        et dans la case 1 les mots clefs en negatif **/
        
		Resultat = pOM.plusOuMoins(recherche);
		
		try {
		    /** 2eme etape :Les mots Clefs positifs sont donnés à la methode rechercheMotClefs qui remplit le fichier texte resultatPos.txt **/
			rmc.rechercheMotClefs(Resultat.get(0));
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
		    /** 3eme etape: Les mots Clefs negatifs sont donnés à la methode rechercheMotClefsInv qui remplit le fichier texte resultatInv.txt **/
			ri.rechercheMotClefsInv(Resultat.get(1));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 

        /** 4eme etape: On fait la difference entre les fichiers resultatPos.txt et resultatInv.txt et on recupere la difference dans le fichier resultat.txt  **/
		dR.differenceRecherche();
		Resultat.clear();
	}

}
