package control;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import model.BDAdmin;
import model.BDUtilisateur;
import model.Utilisateur;

public class ControlChargerBD {
	
	BDUtilisateur bde = BDUtilisateur.getInstance();
	BDAdmin bda = BDAdmin.getInstance();
	
	public void controlChargerBD(){
		
		bda.chargerAdmin();
		bde.chargerUtilisateur();
	}
	
	

}
