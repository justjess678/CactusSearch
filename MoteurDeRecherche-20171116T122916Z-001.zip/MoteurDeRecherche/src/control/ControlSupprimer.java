package control;

import model.BDAdmin;
import model.BDUtilisateur;
import model.Stockage;

public class ControlSupprimer {
	
	BDUtilisateur bdUtilisateur = BDUtilisateur.getInstance();
	BDAdmin bdAdmin = BDAdmin.getInstance();
	Stockage stock = Stockage.getInstance();
	
	public void controlSupprimerUtilisateur(){
		
		bdUtilisateur.deconnexionUtilisateur(stock.getLogin(),stock.getMdp());
		bdUtilisateur.supprimerUtilisateur(stock.getNumeroUtil());
		bdUtilisateur.enregistrerUtilisateur();
		stock.setNumeroUtil(-1);
		stock.setLogin("");
		stock.setMdp("");
		
	}
	
	public void controlSupprimerAdmin(){
		
		bdAdmin.deconnexionAdmin(stock.getLogin(),stock.getMdp());
		bdAdmin.supprimerAdmin(stock.getNumeroUtil());
		bdAdmin.enregistrerAdmin();
		stock.setNumeroUtil(-1);
		stock.setLogin("");
		stock.setMdp("");
		
	}

}
