package control;

import java.io.IOException;
import model.BDAdmin;
import model.Indexation;
import model.ProfilClient;

/** Auteur: Nicolas Mallent **/
public class ControlIndexation {
	ControlVerificationIdentification cvi = new ControlVerificationIdentification();
	BDAdmin bdAdmin = BDAdmin.getInstance();
	Indexation indexation = new Indexation();

	public void controlIndexation(int numeroProfil) throws IOException {
		String login;
		String mdp;
		
		/** L'indexation est accessible que par les administrateurs, 
		on doit donc vérifier qui est connecté **/
		
		if (cvi.verificationIdentification(ProfilClient.ADMIN, numeroProfil)) {
			indexation.indexation();
		} else {
			System.out.println("Vous n'avez pas acces à l'indexation si vous n'etes pas administrateur");
		}
	}
}
