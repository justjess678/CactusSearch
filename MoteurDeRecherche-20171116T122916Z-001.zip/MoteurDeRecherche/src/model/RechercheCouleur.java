package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * Dans cette classe, on peut faire la recherche par couleur dominante en
 * fonction de la couleur demandée, le programme regarder l'histogramme de
 * toutes les images (il regarde dans le fichier BdDescripteurImagesRGB.txt) 
 * puis il regarder tel ou tel pixel (le pixel 48 pour les
 * images rouges, le 4 pour les vert, etc...). 
 * Les images qui satisfont la condition (condition : tel pixel présent plus de X fois, 
 * exemple: le pixel 48 présent plus de 1000 fois dans l'image ) sont ensuite
 * stocker dans une arrayList puis retourner au control.
 **/

/** Auteur: Nicolas Mallent **/
public class RechercheCouleur {

	public static ArrayList<String> rechercheCouleur(String couleur)
			throws IOException {
	    
	    //Declaration
		ArrayList<String> histogrammeString = new ArrayList<String>();
		ArrayList<Integer> histogramme = new ArrayList<Integer>();
		ArrayList<String> resultat = new ArrayList<String>();
		int i = 0;
		String nom;

		switch (couleur) {
		case "rouge":
			try {
			    /** f est le fichier où il y a tout les descripteurs des images RGB **/
				File f = new File(
						"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basededonneedescripteurs/BdDescripteurImageRGB.txt");
				FileReader fr = new FileReader(f);
				BufferedReader br = new BufferedReader(fr);
				try {
				    /** On lit la ligne **/
					String line = br.readLine();
					/** On définit les délimiteurs entre chaque pixel **/
					StringTokenizer st = new StringTokenizer(line, ":");
					
					@SuppressWarnings("resource")
					Scanner scanner = new Scanner(f);

					do {
                        /** Tant qu'il y a un délimiteur **/
						while (st.hasMoreTokens()) {
                            /** On stock les valeurs dans une arrayList de String **/
							histogrammeString.add(st.nextToken());
						}
                    	/** On récupère le nom du descripteur **/
						nom = histogrammeString.get(1);
					
                        /** On enleve l'identifiant du descripteur **/
						histogrammeString.remove(0);
						
						/** On enleve le nom du descripteur **/
						histogrammeString.remove(0);
						

                        /** On stock dans une autre arrayList (histogramme)
						*la convertion en Int de la 1ere ArrayList
						*(histogrammeString)
						**/
						for (int j = 0; j < 64; j++) {
							
							histogramme.add(Integer.parseInt(histogrammeString
									.get(j)));
						}

						/**
						 * On parcours ici l'histogramme et on regarde le pixel
						 * 48, si il est superieur a 1000 alors l'image est
						 * rouge
						 **/
						for (i = 0; i < 64; i++) {
							if (i == 48) {
								if (histogramme.get(i) > 1000) {
									resultat.add(nom);

								}
							}
						}
						/** On reinitialise les arrayLists **/
						histogramme.removeAll(histogramme);
						histogrammeString.removeAll(histogrammeString);
						line = scanner.nextLine();
						st = new StringTokenizer(line, ":");
					} while (scanner.hasNextLine());

					br.close();
					fr.close();

					return resultat;

				} catch (IOException exception) {
					System.out.println("Erreur lors de la lecture : "
							+ exception.getMessage());
				}
			} catch (FileNotFoundException exception) {
				System.out.println("Le fichier n'a pas été trouvé");
			}
			break;

		case "vert":
			try {
				File f = new File("/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basededonneedescripteurs/BdDescripteurImageRGB.txt");
				FileReader fr = new FileReader(f);
				BufferedReader br = new BufferedReader(fr);
				try {
					String line = br.readLine();
					StringTokenizer st = new StringTokenizer(line, ":");
					/** On définit les délimiteurs entre chaque pixel **/
					@SuppressWarnings("resource")
					Scanner scanner = new Scanner(f);

					do {

						while (st.hasMoreTokens()) {
							histogrammeString.add(st.nextToken());
							/**
							 * On stock les valeurs dans une arrayList de String
							 **/
						}

						nom = histogrammeString.get(1);
						/** On récupère le nom du descripteur **/

						histogrammeString.remove(0);
						/** On enleve le numero du descripteur **/
						histogrammeString.remove(0);
						/** On enleve le nom du descripteur **/

						for (int j = 0; j < 64; j++) {
							/**
							 * On stock dans une autre arrayList (histogramme)
							 * la convertion en Int de la 1ere ArrayList
							 * (histogrammeString)
							 **/
							histogramme.add(Integer.parseInt(histogrammeString
									.get(j)));
						}

						/**
						 * On parcours ici l'histogramme et on regarde le pixel
						 * 4, si il est superieur a 1000 alors l'image est
						 * verte
						 **/
						for (i = 0; i < 64; i++) {
							if (i == 4) {
								if (histogramme.get(i) > 1000) {
									resultat.add(nom);
								}
							}
						}
						histogramme.removeAll(histogramme);
						histogrammeString.removeAll(histogrammeString);
						line = scanner.nextLine();
						st = new StringTokenizer(line, ":");
					} while (scanner.hasNextLine());

					br.close();
					fr.close();

					return resultat;

				} catch (IOException exception) {
					System.out.println("Erreur lors de la lecture : "
							+ exception.getMessage());
				}
			} catch (FileNotFoundException exception) {
				System.out.println("Le fichier n'a pas été trouvé");
			}

			break;
		case "bleu":
			try {
				File f = new File("/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basededonneedescripteurs/BdDescripteurImageRGB.txt");
				FileReader fr = new FileReader(f);
				BufferedReader br = new BufferedReader(fr);
				try {
					String line = br.readLine();
					StringTokenizer st = new StringTokenizer(line, ":");
					/** On définit les délimiteurs entre chaque pixel **/
					@SuppressWarnings("resource")
					Scanner scanner = new Scanner(f);

					do {

						while (st.hasMoreTokens()) {
							histogrammeString.add(st.nextToken());
							/**
							 * On stock les valeurs dans une arrayList de String
							 **/
						}

						nom = histogrammeString.get(1);
						/** On récupère le nom du descripteur **/

						histogrammeString.remove(0);
						/** On enleve le numero du descripteur **/
						histogrammeString.remove(0);
						/** On enleve le nom du descripteur **/

						for (int j = 0; j < 64; j++) {
							/**
							 * On stock dans une autre arrayList (histogramme)
							 * la convertion en Int de la 1ere ArrayList
							 * (histogrammeString)
							 **/
							histogramme.add(Integer.parseInt(histogrammeString
									.get(j)));
						}

						
						/**
						 * On parcours ici l'histogramme et on regarde le pixel
						 * 1, si il est superieur a 1000 alors l'image est
						 * bleu
						 **/
						for (i = 0; i < 64; i++) {
							if ((i == 1)) {
								if (histogramme.get(i) > 1000) {
									resultat.add(nom);
								}
							}
						}
						histogramme.removeAll(histogramme);
						histogrammeString.removeAll(histogrammeString);
						line = scanner.nextLine();
						st = new StringTokenizer(line, ":");
					} while (scanner.hasNextLine());

					br.close();
					fr.close();

					return resultat;

				} catch (IOException exception) {
					System.out.println("Erreur lors de la lecture : "
							+ exception.getMessage());
				}
			} catch (FileNotFoundException exception) {
				System.out.println("Le fichier n'a pas été trouvé");
			}

			break;
		case "jaune":
			try {
				File f = new File("BdDescripteurImageRGB.txt");
				FileReader fr = new FileReader(f);
				BufferedReader br = new BufferedReader(fr);
				try {
					String line = br.readLine();
					StringTokenizer st = new StringTokenizer(line, ":");
					/** On définit les délimiteurs entre chaque pixel **/
					@SuppressWarnings("resource")
					Scanner scanner = new Scanner(f);

					do {

						while (st.hasMoreTokens()) {

							histogrammeString.add(st.nextToken());
							/**
							 * On stock les valeurs dans une arrayList de String
							 **/
						}

						nom = histogrammeString.get(1);
						/** On récupère le nom du descripteur **/

						histogrammeString.remove(0);
						/** On enleve le numero du descripteur **/
						histogrammeString.remove(0);
						/** On enleve le nom du descripteur **/

						for (int j = 0; j < 64; j++) {
							/**
							 * On stock dans une autre arrayList la convertion
							 * en Int de la 1ere ArrayList
							 **/
							histogramme.add(Integer.parseInt(histogrammeString
									.get(j)));
						}

						
						/**
						 * On parcours ici l'histogramme et on regarde le pixel
						 * 27, si il est superieur a 900 alors l'image est
						 * jaune
						 **/
						for (i = 0; i < 64; i++) {
							if (i == 27) {
								if (histogramme.get(i) > 900) {
									resultat.add(nom);

								}
							}
						}
						histogramme.removeAll(histogramme);
						histogrammeString.removeAll(histogrammeString);
						line = scanner.nextLine();
						st = new StringTokenizer(line, ":");
					} while (scanner.hasNextLine());

					br.close();
					fr.close();

					return resultat;

				} catch (IOException exception) {
					System.out.println("Erreur lors de la lecture : "
							+ exception.getMessage());
				}
			} catch (FileNotFoundException exception) {
				System.out.println("Le fichier n'a pas été trouvé");
			}
			break;

		}

		return null;
	}

}
