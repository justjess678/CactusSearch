package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class BDUtilisateur {

	Map<Integer, Utilisateur> listeUtilisateurs = new HashMap<>();

	private static BDUtilisateur instance = null;

	private BDUtilisateur() {
	}

	public static BDUtilisateur getInstance() {
		if (instance == null) {
			instance = new BDUtilisateur();
		}
		return instance;
	}

	public Utilisateur getUtilisateur(int numeroUtilisateur) {
		return instance.listeUtilisateurs.get(numeroUtilisateur);
	}

	public Map<Integer, Utilisateur> getlisteUtilisateurs() {
		return instance.listeUtilisateurs;
	}

	public int connexionUtilisateur(String login, String mdp) {
		int res = -1;
		for (int key : instance.listeUtilisateurs.keySet()) {
			if (instance.listeUtilisateurs.get(key).selecteProfil(login, mdp)) {
				res = key;
			}
		}
		if (res < 0) {
			// System.out.println("Erreur lors de la connexion");
			return -1;

		} else {
			instance.listeUtilisateurs.get(res).connexionProfil();
			return res;
		}
	}

	public boolean listeUtilisateursIsEmpty() {
		return instance.listeUtilisateurs.isEmpty();
	}

	public void ajouterUtilisateur(Utilisateur u) {
		int key = instance.listeUtilisateurs.size() + 1;
		instance.listeUtilisateurs.put(key, u);
	}

	public void majUtilisateur(Utilisateur u, int numProfil) {
		instance.listeUtilisateurs.put(numProfil, u);
	}

	public String toString() {
		String s = "Base de donnees des Utilisateurs:\n";

		if (instance.listeUtilisateurs.size() != 0)
			for (int key : instance.listeUtilisateurs.keySet()) {
				s += key + listeUtilisateurs.get(key).toString() + "\n";
			}
		else
			s = "base de données vide";
		return s;
	}

	public void supprimerUtilisateur(int numProfil) {
		instance.listeUtilisateurs.remove(numProfil);
	}

	public void deconnexionUtilisateur(String login, String mdp) {
		int res = -1;
		for (int key : instance.listeUtilisateurs.keySet()) {
			if (instance.listeUtilisateurs.get(key).selecteProfil(login, mdp)) {
				res = key;
			}
		}
		if (res < 0) {

		} else {
			instance.listeUtilisateurs.get(res).deconnexionProfil();

		}

	}

	public void enregistrerUtilisateur() {
		String s = "";
		File MyFile = new File(
				"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/fichierUtilisateurs.txt");
		MyFile.delete();

		try {
			MyFile.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated
			e1.printStackTrace();
		}

		if (instance.listeUtilisateurs.size() != 0) {
			for (int key : instance.listeUtilisateurs.keySet()) {
				s = key + listeUtilisateurs.get(key).toString() + "\n";
				try (FileWriter writer = new FileWriter(
						"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/fichierUtilisateurs.txt",
						true)) {
					writer.write(s);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public void chargerUtilisateur() {

		try (Scanner scanner = new Scanner(
				new File(
						"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/fichierUtilisateurs.txt"))) {
			// On boucle sur chaque champ détecté.

			while (scanner.hasNextLine()) {

				Utilisateur u = new Utilisateur();

				String[] motSepare;
				String line = scanner.nextLine();

				motSepare = line.split(" ");

				u.creerProfilUtilisateur(motSepare[1], motSepare[2],
						motSepare[3], motSepare[4]);
				// System.out.println(u.toString());

				this.ajouterUtilisateur(u);

				// System.out.println(this.toString());
			}
		} catch (FileNotFoundException ex) {
			System.out.println("Erreur --" + ex.toString());
		}

	}

}
