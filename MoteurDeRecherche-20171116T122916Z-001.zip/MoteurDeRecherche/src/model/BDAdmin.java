package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class BDAdmin {

	Map<Integer, Admin> listeAdmins = new HashMap<>();

	private static BDAdmin instance = null;

	private BDAdmin() {
	}

	public static BDAdmin getInstance() {
		if (instance == null) {
			instance = new BDAdmin();
		}
		return instance;
	}

	public Admin getAdmin(int numeroAdmin) {
		return instance.listeAdmins.get(numeroAdmin);
	}

	public int connexionAdmin(String login, String mdp) {
		int res = -1;
		for (int key : instance.listeAdmins.keySet()) {
			if (instance.listeAdmins.get(key).selecteProfil(login, mdp)) {
				res = key;
			}
		}
		if (res < 0) {
			// System.out.println("Erreur lors de la connexion");
			return -1;
		} else {
			instance.listeAdmins.get(res).connexionProfil();
			return res;
		}
	}

	public void majAdmin(Admin a, int numProfil) {
		instance.listeAdmins.put(numProfil, a);
	}

	public Map<Integer, Admin> getlisteAdmins() {
		return instance.listeAdmins;
	}

	public boolean listeAdminIsEmpty() {
		return instance.listeAdmins.isEmpty();
	}

	public void ajouterAdmin(Admin a) {
		int key = listeAdmins.size() + 1;
		instance.listeAdmins.put(key, a);
	}

	public void supprimerAdmin(int numProfil) {
		instance.listeAdmins.remove(numProfil);
	}

	public void deconnexionAdmin(String login, String mdp) {

		int res = -1;
		for (int key : instance.listeAdmins.keySet()) {
			if (instance.listeAdmins.get(key).selecteProfil(login, mdp)) {
				res = key;
			}
		}
		if (res < 0) {

		} else {
			instance.listeAdmins.get(res).deconnexionProfil();
		}

	}

	public String toString() {
		String s = "Base de donnees des Admins:\n";
		if (instance.listeAdmins.size() != 0)
			for (int key : instance.listeAdmins.keySet()) {
				s += key + listeAdmins.get(key).toString() + "\n";
			}
		else
			s = "base de données vide";
		return s;
	}

	public void enregistrerAdmin() {
		String s = "";
		File MyFile = new File(
				"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/fichierAdmins.txt");
		MyFile.delete();
		try {
			MyFile.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		if (instance.listeAdmins.size() != 0) {
			for (int key : instance.listeAdmins.keySet()) {
				s = key + listeAdmins.get(key).toString() + "\n";
				try (FileWriter writer = new FileWriter(
						"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/fichierAdmins.txt",
						true)) {
					writer.write(s);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public void chargerAdmin() {

		try (Scanner scanner = new Scanner(
				new File(
						"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/fichierAdmins.txt"))) {
			// On boucle sur chaque champ détecté.

			while (scanner.hasNextLine()) {

				Admin u = new Admin();

				String[] motSepare;
				String line = scanner.nextLine();

				motSepare = line.split(" ");

				u.creerProfilAdmin(motSepare[1], motSepare[2], motSepare[3],
						motSepare[4]);
				// System.out.println(u.toString());

				this.ajouterAdmin(u);

				// System.out.println(this.toString());
			}
		} catch (FileNotFoundException ex) {
			System.out.println("Erreur --" + ex.toString());
		}

	}

}
