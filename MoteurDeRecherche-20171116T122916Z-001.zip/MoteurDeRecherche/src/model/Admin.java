package model;

public class Admin extends Profil {
	
	public void creerProfilAdmin(String login, String mdp, String nom,
			String prenom) {
		//demander mot de passe super
		super.creerProfil(login, mdp, nom, prenom);
	}

	public String toString() {
		return " " + getLogin()+ " " + getMdp() +" " + getNom() + " " + getPrenom();
	}
}
