package model;

public enum ProfilClient {
	
	UTILISATEUR, ADMIN;

}
