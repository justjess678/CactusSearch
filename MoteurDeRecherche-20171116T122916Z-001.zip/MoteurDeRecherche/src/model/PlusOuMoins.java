package model;

import java.util.ArrayList;

public class PlusOuMoins {
	
	private String[] motSepare;
	private String lesPlus = "";
	private String lesMoins = "";
	ArrayList<String> Resultat = new ArrayList<String>();
	
	public ArrayList<String> plusOuMoins(String motClefs){
		
		Resultat.clear();
		
		motSepare = motClefs.split(" ");
		for (String mot : motSepare){
			if(mot.indexOf("-") != -1){
				mot = mot.replace("-", "");
				lesMoins = lesMoins+ mot  + " " ;
				
			}
			else {
				mot = mot.replace("+","");
				lesPlus = lesPlus + mot  + " ";
				
			}
		}
		
		Resultat.add(lesPlus);
		Resultat.add(lesMoins);
		
		lesPlus = "";
		lesMoins = "";
		
		return Resultat;
			
	}
	
 
}
