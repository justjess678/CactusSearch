package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class VisualiserHistorique {

	public ArrayList<String> visulaiserHistoriqueUtilisateur(int numeroProfil) {
		ArrayList<String> histo = new ArrayList<String>();

/** Attention l'historique devra etre afficher dans l'interface graphique !!!! **/
		try {

			FileInputStream fis = new FileInputStream(
					"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/BDHistorique/"
							+ numeroProfil + "_historiqueUtilisateur.txt");
			try (Scanner scanner = new Scanner(fis)) {

				while (scanner.hasNextLine()) {
					String line = scanner.nextLine();
					histo.add(line);
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("Historique introuvable");
		}
		
		return histo;

	}
	
	public ArrayList<String> visulaiserHistoriqueAdmin(int numeroProfil) {
		
		ArrayList<String> histo = new ArrayList<String>();

		/** Attention l'historique devra etre afficher dans l'interface graphique !!!! **/
				try {

					FileInputStream fis = new FileInputStream(
							"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/BDHistorique/"
									+ numeroProfil + "_historiqueAdmin.txt");
					try (Scanner scanner = new Scanner(fis)) {

						while (scanner.hasNextLine()) {
							String line = scanner.nextLine();
							histo.add(line);
						}
					}
				} catch (FileNotFoundException e) {
					System.out.println("Historique introuvable");
				}
				
				return histo;

			}

}
