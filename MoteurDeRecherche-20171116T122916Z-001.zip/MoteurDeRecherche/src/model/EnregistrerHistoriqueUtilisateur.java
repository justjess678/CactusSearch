package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class EnregistrerHistoriqueUtilisateur {

	public void enregistrerHistoriqueUtilisateur(int numeroProfil) {
		try {
			Scanner scanner = new Scanner(
					new File(
							"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/resultat.txt"));
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				// System.out.println(line);
				try (FileWriter writer = new FileWriter(
						"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/BDHistorique/"
								+ numeroProfil + "_historiqueUtilisateur.txt",
						true)) {
					writer.write(line);
					writer.write("\r\n");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
