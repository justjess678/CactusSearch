package model;

/** Cette classe nous permet de stocker le numero d'utilisateur,
le login et le mot de passe de la personne connectée.
Ca nous permet de pouvoir recuperer facilement ces trois informations facilement.
On stock les informations quand un utilisateur se connecte ou quand il s'inscrit.
On les efface quand l'utilisateur se deconnecte ou supprime son compte**/

/** Auteur: Nicolas Mallent et Louis Dhellemmes **/

public class Stockage {

	int numeroUtil;
	String login;
	String mdp;
	
	/** On a définit cette classe comme un singleton car on a besoin que d'une
	seul instance de cette classe dans tout notre code **/
	
	private static Stockage instance = null;

	private Stockage() {
	}

	public static Stockage getInstance() {
		if (instance == null) {
			instance = new Stockage();
		}
		return instance;
	}
	public int getNumeroUtil() {
		return numeroUtil;
	}

	public void setNumeroUtil(int numeroUtil) {
		this.numeroUtil = numeroUtil;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getMdp() {
		return mdp;
	}

	public void setMdp(String mdp) {
		this.mdp = mdp;
	}
	
	
}
