package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Cette classe permet de faire la recherche par mot clef "positive". Si il y a
 * un mot clef, on lance la fonction C RechercheMotClefs. Sinon on recupere le
 * nom de tout les fichier textes de la base de donnée et on les ecris dans le
 * fichier resultatPos.txt
 **/
 
 /** Auteur: Nicolas Mallent **/

public class RechercheMotClefs {

    /** Declaration du RunTime **/
	static Runtime runtime = Runtime.getRuntime();

	public void rechercheMotClefs(String motClefs) throws IOException {
		try {
		    /** Si il n'y a aucun mot clef, on recupere le nom de tout les fichiers 
		     textes et on les "colle" dans le fichier resultatPos.txt **/
			if (motClefs.equals("")) {

				File repertoire = new File(
						"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basedeDonneefichier/Textes");
				String[] nomFichiers = repertoire.list();

				for (int i = 0; i < nomFichiers.length; i++) {
					try (FileWriter writer = new FileWriter(
							"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/resultatPos.txt",
							true)) {
						writer.write(nomFichiers[i]);
						writer.write("\n");
					}
				}
			} else {
				try {
				    /** Sinon on lance la fonction C RechercheMotClefs avec pour parametre les mots clefs **/
					Process p = Runtime
							.getRuntime()
							.exec("/home/mallent/Informatique/MoteurDeRecherche_G3/RechercheMotClefs/RechercheMotClefs "
									+ motClefs);

					BufferedReader stdInput = new BufferedReader(
							new InputStreamReader(p.getInputStream()));

					BufferedReader stdError = new BufferedReader(
							new InputStreamReader(p.getErrorStream()));

				} catch (IOException e) {
					System.out
							.println("exception happened - here's what I know: ");
					e.printStackTrace();
					System.exit(-1);
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
