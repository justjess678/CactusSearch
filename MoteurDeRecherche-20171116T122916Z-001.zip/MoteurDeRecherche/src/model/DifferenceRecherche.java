package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class DifferenceRecherche {

	String linePos;
	String lineInv;

	public void differenceRecherche() {

		File resultatPos = new File(
				"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/resultatPos.txt");
		File resultatInv = new File(
				"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/resultatInv.txt");

		File MyFile = new File(
				"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/resultat.txt");
		
		MyFile.delete();

		try {
			MyFile.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated
			e1.printStackTrace();
		}
		/** Thread.sleep qui permet d'attendre que les fichier resultatPos.txt et resultatInv.txt soit mis à jour **/
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		try (Scanner scanner = new Scanner(resultatPos)) {
			while (scanner.hasNextLine()) {
				linePos = scanner.nextLine();
				//System.out.println("linePos= " + linePos);
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				try (Scanner scanner1 = new Scanner(resultatInv)) {

					// Lecture du fichier ligne par ligne.
					// Cette boucle se termine quand la methode retourne la
					// valeur null.
					while (scanner1.hasNextLine()) {
						lineInv = scanner1.nextLine();
						//System.out.println("lineInv= "+lineInv);
						if (linePos.equals(lineInv)) {
							//System.out.println(linePos.equals(lineInv));
							try (FileWriter writer = new FileWriter(MyFile,
									true)) {
								writer.write(linePos);
								writer.write("\r\n");
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}

					}
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean equals(Object obj) {
		if (obj instanceof String) {
			String line = (String) obj;
			return linePos.equals(line);
		}
		return false;
	}
}
