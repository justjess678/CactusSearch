package model;

public abstract class Profil {
	boolean connecte = false;
	private String login;
	private String mdp;
	private String nom;
	private String prenom;

	public void creerProfil(String login, String mdp, String nom, String prenom) {
		this.login = login;
		this.mdp = mdp;
		this.nom = nom;
		this.prenom = prenom;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public void setMdp(String mdp) {
		this.mdp = mdp;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public boolean isConnecte() {
		return connecte;
	}
	
	public void deconnexionProfil() {
		this.connecte=false;		
	}

	public boolean selecteProfil(String login, String mdp) {
		if (this.login.equals(login) && this.mdp.equals(mdp)) {

			return true;
		} else {
			return false;
		}
	}

	public void connexionProfil() {
		this.connecte = true;
	}

	public String getLogin() {
		return login;
	}

	public String getMdp() {
		return mdp;
	}
	
	public String getPrenom() {
		return prenom;
	}

	public String getNom() {
		return nom;
	}


}
