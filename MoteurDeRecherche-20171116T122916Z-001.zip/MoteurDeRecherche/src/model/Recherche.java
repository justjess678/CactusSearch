package model;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/** Dans cette classe nous appellons l'executable Recherche implémenté en C (pour les textes et images) **/
/** Auteur: Nicolas Mallent **/
public class Recherche {

	static Runtime runtime = Runtime.getRuntime();

	public static void recherche(String chemin) throws IOException {

		String s = null;

		try {
			System.out.println(chemin);
			/* Execution de la recherche avec le chemin du fichier en parametre*/
			Process p = Runtime.getRuntime().exec(
					"/home/mallent/Informatique/MoteurDeRecherche_G3/Recherche/Recherche "
							+ chemin);

			BufferedReader stdInput = new BufferedReader(new InputStreamReader(
					p.getInputStream()));

			BufferedReader stdError = new BufferedReader(new InputStreamReader(
					p.getErrorStream()));

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
