package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

/** Cette classe permet d'afficher les résultats dans le vue textuelle du moteur de recherche **/
/** Auteur : Clement et Nicolas **/

public class AfficherResultat {
	// declaration
	private String line;
	private ArrayList<String> resu = new ArrayList<String>();

	// Methode
	public ArrayList<String> afficherResultat() {

		try {
			/** On vide notre arrayList et on crée une variable de type File qui contient le fichier resultat.txt (le fichier où on enregistre les resultats apres chaque recherche)**/
			resu.removeAll(resu);
			File f = new File("/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/resultat.txt");
			
			Scanner scanner = new Scanner(f);
			int index = 0;
			while (true) {

				try {
                    /** Lecture de chaque line et chaque line enregistrer dans l'arrayList resu **/
					line = scanner.next();
					resu.add(index, line);
				} catch (NoSuchElementException exception) {
					break;
				}
			}
			scanner.close();
		} catch (FileNotFoundException exception) {
			System.out.println("Le fichier n'a pas été trouvé");
		}
		return resu;
	}
}
