package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class VisualiserBD {

	public ArrayList<String> visulaiserBDUtilisateur() {
		ArrayList<String> bd = new ArrayList<String>();

		/**
		 * Attention l'historique devra etre afficher dans l'interface graphique
		 * !!!!
		 **/
		try {

			FileInputStream fis = new FileInputStream(
					"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/fichierUtilisateurs.txt");
			try (Scanner scanner = new Scanner(fis)) {

				while (scanner.hasNextLine()) {
					String line = scanner.nextLine();
					bd.add(line);
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("bd introuvable");
		}

		return bd;

	}

	public ArrayList<String> visulaiserBDAdmin() {
		ArrayList<String> bd = new ArrayList<String>();

		/**
		 * Attention l'historique devra etre afficher dans l'interface graphique
		 * !!!!
		 **/
		try {

			FileInputStream fis = new FileInputStream(
					"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/fichierAdmins.txt");
			try (Scanner scanner = new Scanner(fis)) {

				while (scanner.hasNextLine()) {
					String line = scanner.nextLine();
					bd.add(line);
				}
			}
		} catch (FileNotFoundException e) {
			System.out.println("bd introuvable");
		}

		return bd;

	}

}
