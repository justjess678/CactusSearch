package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Cette classe permet de faire la recherche par mot clef "negative". Si il y a
 * un mot clef, on lance la fonction C RechercheMotClefsInv. Sinon on recupere
 * le nom de tout les fichier textes de la base de donnée et on les ecris dans
 * le fichier resultatInv.txt
 **/
 
 /** Auteur: Nicolas Mallent **/
public class RechercheMotClefsInv {

	static Runtime runtime = Runtime.getRuntime();


	public void rechercheMotClefsInv(String motClefs) throws IOException {
	    
		/** Declaration **/
		String resultatInv = "/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/options/resultatInv.txt";
		File fichierResultat = new File(resultatInv);
		/** On supprime et recrée le fichier resultatInv.txt pour eviter d'ecrire
		à la suite du fichier quand on fait des recherches succevives **/
		fichierResultat.delete();
		try {
			fichierResultat.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
		
		try {
		    /** Si il n'y a pas de mot clefs, on recupere les noms des fichiers textes et on les colle dans resultatInv.txt **/
			if (motClefs.equals("")) {

				File repertoire = new File(
						"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basedeDonneefichier/Textes");
				String[] nomFichiers = repertoire.list();

				for (int i = 0; i < nomFichiers.length; i++) {
					try (FileWriter writer = new FileWriter(fichierResultat,true)) {
						writer.write(nomFichiers[i]);
						writer.write("\n");
					}
				}
			} else {
                /** Sinon on lance avec runtime la fonction C RechercheMotClefsInv avec les mots Clefs donnéss **/
				Process p = Runtime
						.getRuntime()
						.exec("/home/mallent/Informatique/MoteurDeRecherche_G3/RechercheMotClesInverse/RechercheMotClefsInv "
								+ motClefs);

				BufferedReader stdInput = new BufferedReader(
						new InputStreamReader(p.getInputStream()));

				BufferedReader stdError = new BufferedReader(
						new InputStreamReader(p.getErrorStream()));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
