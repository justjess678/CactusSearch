package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

/** Classe permettant de lancer l'indexation des fichiers, cette méthode appelle la fonction d'indexation implémenté en C **/
/** Auteur: Nicolas Mallent **/

public class Indexation {
    
    //Declaration
	static Runtime runtime = Runtime.getRuntime();
	/** Tableau de String contenant les chemins des dossiers des fichiers Textes/ImagesRGB/ImagesNB **/
	final static String[] chemin = {
			"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basedeDonneefichier/Textes ",
			"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basedeDonneefichier/IMG_NG ",
			"/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basedeDonneefichier/IMG_RGB" };
    //Methode
	public void indexation() throws IOException {

		String s = null;

        /** On crée le fichier Textes avec son chemin recupéré du tableau de String **/
		File Texte = new File("/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basesesonneedescripteurs/BdDescripteur.txt");
		/** On supprime le fichier (sinon on va ecrire à la suite) **/
		Texte.delete();
		/** Et on en créer un nouveau **/
		try {
			Texte.createNewFile();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
		
		/** On crée le fichier Textes avec son chemin recupéré du tableau de String **/
		File ImageRGB = new File("/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basesesonneedescripteurs/BdDescripteurImageRGB.txt");
		/** On supprime le fichier (sinon on va ecrire à la suite) **/
		ImageRGB.delete();
		/** Et on en créer un nouveau **/
		try {
			ImageRGB.createNewFile();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		/** On crée le fichier Textes avec son chemin recupéré du tableau de String **/
		File ImageNB = new File("/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basesesonneedescripteurs/BdDescripteurImage.txt");
		/** On supprime le fichier (sinon on va ecrire à la suite) **/
		ImageNB.delete();
		/** Et on en créer un nouveau **/
		try {
			ImageNB.createNewFile();
		} catch (IOException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		
		try {
        /** On lance les trois indexation (textes, imagesRGB et imagesNB) dans trois processus differents.
         * Dans le RunTime: On met d'abord l'emplacement de l'executable puis les parametres dont l'executable a besoin pour fonctionner
         * Ici, le parametre, c'est le chemin du dossier des fichiers a indexer.
        **/

			Process p = Runtime.getRuntime().exec(
					"/home/mallent/Informatique/MoteurDeRecherche_G3/IndexationTextes/Indexation "
							+ chemin[0]);
			Process p1 = Runtime
					.getRuntime()
					.exec("/home/mallent/Informatique/MoteurDeRecherche_G3/IndexationImagesNB/Indexation "
							+ chemin[1]);
			Process p2 = Runtime
					.getRuntime()
					.exec("/home/mallent/Informatique/MoteurDeRecherche_G3/IndexationImagesRGB/Indexation "
							+ chemin[2]);

			BufferedReader stdInput = new BufferedReader(new InputStreamReader(
					p.getInputStream()));

			BufferedReader stdError = new BufferedReader(new InputStreamReader(
					p.getErrorStream()));

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
