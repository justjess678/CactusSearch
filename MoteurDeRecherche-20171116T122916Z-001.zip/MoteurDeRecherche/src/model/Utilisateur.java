package model;

public class Utilisateur extends Profil {
	
	public void modifierProfil(String login, String mdp, String nom,
			String prenom) {
		setLogin(login);
		setMdp(mdp);
		setNom(nom);
		setPrenom(prenom);
	}
	
	public void creerProfilUtilisateur(String login, String mdp, String nom,
			String prenom) {
		super.creerProfil(login, mdp, nom, prenom);
	}

	
	

	@Override
	public String toString() {
		return " " + getLogin()+ " " + getMdp() +" " + getNom() + " " + getPrenom();
	}



}
