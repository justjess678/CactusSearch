package vue;

import java.util.ArrayList;

import model.BDAdmin;
import model.BDUtilisateur;
import model.Stockage;
import control.ControlVisualiserHistorique;

public class BoundaryVisualiserHistorique {
	
	ControlVisualiserHistorique cvh = new ControlVisualiserHistorique();
	BDUtilisateur bdu = BDUtilisateur.getInstance();
	BDAdmin bda = BDAdmin.getInstance();
	Stockage stock = Stockage.getInstance();
	private ArrayList<String> histo = new ArrayList<String>();
	
	
	public ArrayList<String>  boundaryVisualiserHistorique(){
		
		if(!bdu.listeUtilisateursIsEmpty()){
			for (int clef : bdu.getlisteUtilisateurs().keySet()) {
				if (bdu.getlisteUtilisateurs().get(clef).selecteProfil(stock.getLogin(), stock.getMdp())) {
					if(bdu.getUtilisateur(stock.getNumeroUtil()).isConnecte()){
						histo = cvh.controlVisualiserHistoriqueUtilisateur(stock.getNumeroUtil());
					}
				}
			}	
		}
			
		if(!bda.listeAdminIsEmpty()){
			for (int clef : bda.getlisteAdmins().keySet()) {
				if (bda.getlisteAdmins().get(clef).selecteProfil(stock.getLogin(), stock.getMdp())) {
					if(bda.getAdmin(stock.getNumeroUtil()).isConnecte()){
						histo = cvh.controlVisualiserHistoriqueAdmin(stock.getNumeroUtil());
					}
				}
			}
		}
		
		return histo;
	
	}


}
