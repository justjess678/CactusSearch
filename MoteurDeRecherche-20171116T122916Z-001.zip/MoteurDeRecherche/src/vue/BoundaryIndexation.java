package vue;

import java.io.IOException;
import model.Stockage;
import control.ControlIndexation;

/** Auteur: Nicolas Mallent **/
public class BoundaryIndexation {
	static ControlIndexation ci = new ControlIndexation();
	static Stockage stock = Stockage.getInstance();

    /** On lance l'indexation seulement si c'est un admin.
    Donc on donne, en parametre, le numeroProfil de la personne connectée**/
	public void lancerIndexation() {
		// TODO Auto-generated method stub
		try {
			ci.controlIndexation(stock.getNumeroUtil());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
