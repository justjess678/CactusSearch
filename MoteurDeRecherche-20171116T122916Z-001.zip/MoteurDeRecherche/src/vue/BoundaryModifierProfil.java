package vue;


import model.ProfilClient;
import control.ControlModifierProfil;
import control.ControlVerificationIdentification;

public class BoundaryModifierProfil {

	ControlModifierProfil cmp = new ControlModifierProfil();
	ControlVerificationIdentification cvi =  new ControlVerificationIdentification();

	public void modifierProfilUtilisateur(String login,String mdp, String nom, String prenom, int numProfil) {
		
		if(cvi.verificationIdentification(ProfilClient.UTILISATEUR, numProfil)){
			cmp.modifierProfilUtilisateur(login, nom, prenom, mdp, numProfil);
			System.out.println("Profil modifiee");
		}
	}
	
	public void modifierProfilAdmin(String login, String mdp, String nom, String prenom, int numProfil) {

		if(cvi.verificationIdentification(ProfilClient.ADMIN, numProfil)){
			cmp.modifierProfilAdmin(login, nom, prenom, mdp, numProfil);
			System.out.println("Profil modifiee");
		}
}

	public void supprimerUtilisateur(int numProfil) {
		if(cvi.verificationIdentification(ProfilClient.UTILISATEUR, numProfil)){
			cmp.supprimerUtilisateur(numProfil);
			System.out.println("Profil supprimee");
		}
	}
	
	public void supprimerAdmin(int numProfil) {
		if(cvi.verificationIdentification(ProfilClient.ADMIN, numProfil)){
			cmp.supprimerAdmin(numProfil);
			System.out.println("Profil supprimee");
		}
	}


}
