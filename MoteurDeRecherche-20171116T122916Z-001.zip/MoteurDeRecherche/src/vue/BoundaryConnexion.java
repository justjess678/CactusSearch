package vue;

import control.ControlConnexion;

public class BoundaryConnexion {

	ControlConnexion cc = new ControlConnexion();
	
	public int connexion(String login,String mdp){

		return cc.controlConnexion(login, mdp);
		
		
	}

}
