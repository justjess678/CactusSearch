package vue;

import control.ControlRechercheMotClefs;

/** Auteur :Nicolas Mallent **/
public class BoundaryRechercheMotClefs {
	
	ControlRechercheMotClefs cRM = new ControlRechercheMotClefs();
	
	public void rechercheMotClefs(String recherche){
		cRM.rechercheMotClefs(recherche);
		/** Reinitialise "recherche" pour pas garder en memoire l'objet des recherches precedentes**/
		recherche = "";
	}

}
