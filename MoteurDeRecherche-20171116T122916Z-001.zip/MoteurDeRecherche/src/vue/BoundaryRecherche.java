package vue;

import java.io.IOException;
import java.util.Scanner;
import control.ControlRecherche;

/** Boundary de la recherche des textes et des images rgb & nb**/
/** Auteur: Nicolas Mallent **/
public class BoundaryRecherche {
	static ControlRecherche cr = new ControlRecherche();

	public void rechercheTI(String chemin) {
		// TODO Auto-generated method stub
		try {
			cr.controlRecherche(chemin);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
