package vue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import control.ControlRechercheCouleur;

public class BoundaryRechercheCouleur {
	static ControlRechercheCouleur crc = new ControlRechercheCouleur();
	
	/** Les différentes couleurs qu'il est possible de chercher **/
	final static String couleur1 = "rouge";
	final static String couleur2 = "vert";
	final static String couleur3 = "bleu";
	final static String couleur4 = "jaune";


	public void rechCouleur(String couleur) throws IOException {
		// TODO Auto-generated method stub

        /** Si la couleur donnée en parametre existe, on fait la recherche
        Sinon on envoie un message d'erreur**/
		if ((couleur.equals(couleur1)) || (couleur.equals(couleur2))
				|| (couleur.equals(couleur3)) || (couleur.equals(couleur4))) {
				    
			crc.controlRechercheCouleur(couleur);
		} else {
			System.out
					.println("La recherche ne peux pas se faire avec cette couleur");
		}
	}

}
