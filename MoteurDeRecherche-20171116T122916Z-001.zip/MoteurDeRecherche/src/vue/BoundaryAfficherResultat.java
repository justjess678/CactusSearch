package vue;

import java.util.ArrayList;

import control.ControlAfficherResultat;

public class BoundaryAfficherResultat {

	// declaration
	private ArrayList<String> resu = new ArrayList<String>();
	ControlAfficherResultat car = new ControlAfficherResultat();

	// Method
	public ArrayList<String> envoieDataBoundary() {
		/** On continu de stocker les resultats dans une arrayList pour pouvoir 
		la donner à la vu Graphique qui affichera les resultats dans un panel **/
		this.resu = this.car.envoieDataControl();

		return this.resu;
	}
	
}
