package vue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import control.ControlIndexation;

public class BoundaryChoixRecherche {
	//initialisation
	private BoundaryRechercheCouleur brc = new BoundaryRechercheCouleur();
	private BoundaryRecherche br = new BoundaryRecherche();
	private BoundaryAfficherResultat bar = new BoundaryAfficherResultat();
	private BoundaryRechercheMotClefs brmc = new BoundaryRechercheMotClefs();
	private ControlIndexation ci;
	private ArrayList<String> resuT = new ArrayList<String>();
	private ArrayList<String> resuRGB = new ArrayList<String>();
	private ArrayList<String> resuNB = new ArrayList<String>();
	private ArrayList<String> resu = new ArrayList<String>();
	int numeroProfil = 0;

	public void afficherRecherche(int type) {
		Scanner sc = new Scanner(System.in);
		Boolean cont = true;
		do {
			switch (type) {
			case 1:// invite
					// choix pas admin
					// recherche normale
				System.out.println("on fait une recherche");
				affRecherche(1);
				break;
			case 2:// util
				affRecherche(2);
				break;
			case 3:// choix admin
				int rep1;
				do { //demande d'actions admin
					System.out
							.println("-----------------------------------------\n|Que voulez vous faire ?----------------|\n|1-Voir les valeurs des descripteurs----|\n|2-Lancer le processus d'indexation-----|\n|3-Faire une recherche------------------|\n|4-Consulter votre historique-----------|\n-----------------------------------------\n");
					rep1 = sc.nextInt();
					if (rep1 > 4 || rep1 < 1) {//Gestion d'erreur
						System.out
								.println("*********************************************************\n* Erreur : Vous n'avez pas rentre les valeurs attendues *\n* Veuillez recommencer                                  *\n*********************************************************\n");
					}
				} while (rep1 > 4 || rep1 < 1);//boucle tant qu'il n'y a pas d'erreur
				switch (rep1) {
				case 1:// voir valeurs des descripteurs
					System.out.println("valeurs de descripteurs");
					int rep2 = 0;
					System.out
							.println("-----------------------------------\n|Que voulez vous voir ?-----------|\n|1-Voir les descripteurs texte----|\n|2-Voir les descripteurs image NB-|\n|3-Voir les descripteurs image RGB|\n|4-Voir les descripteurs son------|\n-----------------------------------\n");
					do {
						rep2 = sc.nextInt();
						if (rep2 < 1 || rep2 > 4) {
							System.out
									.println("*********************************************************\n* Erreur : Vous n'avez pas rentre les valeurs attendues *\n* Veuillez recommencer                                  *\n*********************************************************\n");
						}
					} while (rep2 < 1 || rep2 > 4);//boucle tant qu'il n'y a pas d'erreur
					switch (rep2) {
					case 1:// descripteurs texte
						System.out.println("descripteurs texte");
						System.out
								.println("/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basededonneedescripteurs/BdDescripteur.txt");
						break;
					case 2:// descripteurs img RGB
						System.out.println("descripteurs RGB");
						System.out
								.println("/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basededonneedescripteurs/BdDescripteurImageRGB.txtBdDescripteurImage.txt");
						break;
					case 3:// descripteurs img NB
						System.out.println("descripteurs NB");
						System.out
								.println("/home/mallent/Informatique/MoteurDeRecherche_G3/FICHIER_PROJET/basededonnee/basededonneedescripteurs/BdDescripteurImage.txt");
					default:
						break;
					}
					break;
				case 2:// lancer indexation
					System.out.println("indexation lancee");
					this.ci = new ControlIndexation();
					try {
						ci.controlIndexation(numeroProfil);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					// si ci a un truc d'indexation, qu'il le fait ici
					break;
				case 3:
					// recherche normale
					System.out.println("on fait une recherche");
					affRecherche(1);
					break;
				case 4:
					// Historique
					System.out.println("Historique");
					break;
				default:

					break;
				}
				break;
			}
			cont = continuer();
		} while (cont);//boucle tant que l'utilisateur veut continuer
		//message de fermeture		
		System.out
				.println("\n      ,`\"\"',        \n      ;' ` ;        \n      ;`,',;        \n      ;' ` ;        \n ,,,  ;`,',;        \n;,` ; ;' ` ;   ,',  \n;`,'; ;`,',;  ;,' ; \n;',`; ;` ' ; ;`'`'; \n;` '',''` `,',`',;  \n `''`'; ', ;`'`'    \n      ;' `';        \n      ;` ' ;        \n      ;' `';        \n      ;` ' ;        \n      ; ',';        \n      ;,' ';        \n  CACTUS SEARCH \n");
		System.out.println("     Au revoir!\n");
		// sc.close();
	}

	public void affRecherche(int util) {
		Scanner sc = new Scanner(System.in);
		int rep1 = 0;
		int maxRep = 0;
		do {
			if (util == 2) {
				maxRep = 6;
				System.out
						.println("--------------------------------------------\n|Quel type de recherche voulez vous faire ?|\n|1-Recherche par mot cle-------------------|\n|2-Comparaison a un descripteur texte------|\n|3-Comparaison a un descripteur image RGB--|\n|4-Comparaison a un descripteur image NB---|\n|5-Recherche par couleur dominante---------|\n|6-Consulter votre historique--------------|\n--------------------------------------------\n");
			} else {
				maxRep = 5;
				System.out
						.println("--------------------------------------------\n|Quel type de recherche voulez vous faire ?|\n|1-Recherche par mot cle-------------------|\n|2-Comparaison a un descripteur texte------|\n|3-Comparaison a un descripteur image RGB--|\n|4-Comparaison a un descripteur image NB---|\n|5-Recherche par couleur dominante---------|\n--------------------------------------------\n");
			}
			rep1 = sc.nextInt();
		} while (rep1 < 1 || rep1 > maxRep);//boucle tant qu'il n'y a pas d'erreur
		switch (rep1) {
		case 1:
			// methode de controlleur recherche mot cle
			System.out.println("rech. par mot cle");
			//brmc.rechercheMotClefs();
			
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			resu = bar.envoieDataBoundary();

			for (int i = 0; i < resu.size(); i++) {
				System.out.println("" + resu.get(i));
			}

			break;
		case 2:
			// methode de controlleur comparer descripteur txt
			System.out.println("rech par desc txt");
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			resuT = bar.envoieDataBoundary();

			for (int i = 0; i < resuT.size(); i++) {
				System.out.println("" + resuT.get(i));
			}

			break;
		case 3:
			// methode de controlleur comparer descripteur img RGB
			System.out.println("rech par decs img RGB");
			//this.br.rechercheTI();
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			resuRGB = bar.envoieDataBoundary();

			for (int i = 0; i < resuRGB.size(); i++) {
				System.out.println("" + resuRGB.get(i));
			}
			break;
		case 4:
			// methode de controlleur comparer descripteur img NB
			System.out.println("rech par desc img NB");
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			resuNB = bar.envoieDataBoundary();

			for (int i = 0; i < resuNB.size(); i++) {
				System.out.println("" + resuNB.get(i));
			}
			// resuNB.removeAll(resuNB);
			break;
		case 5:
			break;
		case 6:
			// Historique
			System.out.println("Historique");
			break;
		default:

			break;
		}
		// sc.close();
	}

	public Boolean continuer() {
		//demande si l'utilsateur veut continuer
		Scanner sc = new Scanner(System.in);
		System.out
				.println("-------------------------------------------\n|Voulez-vous faire une autre manipulation?|\n|-1-Oui-----------------------------------|\n|-2-Non-----------------------------------|\n-------------------------------------------\n");
		int rep1 = sc.nextInt();
		switch (rep1) {
		case 1:// oui
			return true;
		case 2:// non
			return false;
		default:
			return false;
		}

	}
}
