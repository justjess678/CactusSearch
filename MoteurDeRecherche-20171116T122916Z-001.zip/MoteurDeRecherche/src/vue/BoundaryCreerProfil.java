package vue;


import control.ControlCreerProfil;
//modifi�
public class BoundaryCreerProfil {
	
		ControlCreerProfil ccp = new ControlCreerProfil();

		public void creerProfilUtilisateur(String login, String mdp, String nom,
				String prenom) {
			ccp.creerProfilUtilisateur(login, nom, prenom, mdp);
			
		}
		
		public void creerProfilAdmin(String login, String mdp, String nom,
				String prenom, String mdpsu) {
			
			if (mdpsu.equals("porygon")){
				ccp.creerProfilAdmin(login, nom, prenom, mdp);
			}
			else System.out.println("mdp faux");
			
		}
	


}
