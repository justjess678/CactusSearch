package vue;

import java.util.Scanner;

import control.ControlConnexion;

public class BoundaryBienvenue {
	ControlConnexion cc;

	public BoundaryBienvenue(ControlConnexion cc) {
		this.cc = cc;
	}

	/*
	 * retourne le type 1 = invite 2 = util 3 = admin
	 */
	public int messageBienvenue() {
		//initialisation
		Boolean ok = false;
		Scanner sc = new Scanner(System.in);
		//message de bienvenue
		System.out
				.println("\n      ,`\"\"',        \n      ;' ` ;        \n      ;`,',;        \n      ;' ` ;        \n ,,,  ;`,',;        \n;,` ; ;' ` ;   ,',  \n;`,'; ;`,',;  ;,' ; \n;',`; ;` ' ; ;`'`'; \n;` '',''` `,',`',;  \n `''`'; ', ;`'`'    \n      ;' `';        \n      ;` ' ;        \n      ;' `';        \n      ;` ' ;        \n      ; ',';        \n      ;,' ';        \n  CACTUS SEARCH \n");
		int rep1;
		int type = 0;
		//do while pour pouvoir recommencer
		do {
			//demande de type d'utilisation
			System.out
					.println("-----------------------------\n|Veuillez choisir votre mode|\n|1-Recherche Simple---------|\n|2-Connexion----------------|\n-----------------------------\n");
			rep1 = sc.nextInt();
			switch (rep1) {
			case 1:// invite
				ok = true;
				type = 1;
				
				break;
			case 2:// utilisateur
				ok = true;
				String nomUtil = "";
				String mdp = "";
				System.out.println("Nom d'utilisateur:");
				nomUtil = sc.next();
				System.out.println("Mot de Passe:");
				mdp = sc.next();
				/*if (this.cc.connexionAdmin(nomUtil, mdp)) {
					type = 3;
					System.out.println("---> Mode administrateur activee <---");
				} else {
					type = 2;
				}
				break;*/
			default://gestion d'erreur
				System.out
						.println("*********************************************************\n* Erreur : Vous n'avez pas rentre les valeurs attendues *\n* Veuillez recommencer                                  *\n*********************************************************\n");
				break;
			}
		} while (!ok);//parametre a valider pour passer a la suite
		return type;
	}

}
