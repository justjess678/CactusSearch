package vue;

import control.ControlSupprimer;

public class BoundarySupprimerProfil {
	
	ControlSupprimer cs = new ControlSupprimer();
	
	public void supprimerUtilisateur(){
		
		cs.controlSupprimerUtilisateur();
	}
	
	public void supprimerAdmin(){
		
		cs.controlSupprimerAdmin();
		
	}

}
