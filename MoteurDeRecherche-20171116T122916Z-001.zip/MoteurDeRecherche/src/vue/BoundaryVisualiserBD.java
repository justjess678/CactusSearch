package vue;

import java.util.ArrayList;

import control.ControlVisualiserBD;

public class BoundaryVisualiserBD {
	
	ControlVisualiserBD cvbd = new ControlVisualiserBD();
	
	public ArrayList<String> boundaryVisualiserBDUtil(){
		ArrayList<String> bd = new ArrayList<String>();
		bd = cvbd.controlVisualiserBDUtilisateur();
		return bd;
	}
	
	public ArrayList<String> boundaryVisualiserbDAdmin(){
		ArrayList<String> bd = new ArrayList<String>();
		bd = cvbd.controlVisualiserBDAdmin();
		return bd;
		
	}

}
